import sys
import bilibili.Test


if __name__ == '__main__':
    stateStr = sys.argv[1];
    number= bilibili.updateUpStat(stateStr)
    print(number);
