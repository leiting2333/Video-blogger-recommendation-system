from bilibili_api import Credential, sync
from bilibili_api import user
import threading
import pymysql
from dbutils.pooled_db import PooledDB
import time
from bilibili.random_cookie import getParams
import requests
import random
from bilibili.tools.tools import getWtsAndW_rid
from bilibili.random_headers import getHeaders


# 读取文件中的ip地址,可用
def return_proxy_list():
    # 代理IP
    try:
        pro = []  # 代理IP列表
        print("=====================")
        with open(r'./httpipcfg.txt', mode='r', encoding='utf-8') as f:  # 代理IP文档存放路径
            content = f.readline()  # 按行读取
            i = 1
            while content is not None and content != "":  # 循环最后一句的意义为当content读不到行时停止，这样能一行一行全部读取
                op = content.split("@")  # 用op对象存储，把一行切割成数组，去除空格
                pro.append(str(op[0]))  # 第一列数据下标为0
                content = f.readline()
    except Exception as e:
        print(e)
    print('成功载入下列代理IP列表：')
    print(pro)
    return pro


pool = PooledDB(
    creator=pymysql,  # 使用 pymysql 作为数据库连接库
    maxconnections=50,  # 连接池大小为 10
    host='localhost',
    port=3306,
    user='root',
    password='123456',
    database='bilibili',
    charset='utf8mb4'
)
# 假设的数字总数
total_numbers = 1000000000

# 线程数量
num_threads = 50  # 可以根据需要调整线程数量

# 每个线程应该处理的数字数量.
numbers_per_thread = total_numbers // num_threads

# 创建一个锁，用于保护打印输出（可选）
lock = threading.Lock()


def reobj(uid: int):
    params = getParams()
    credential = Credential(sessdata=params["sessdata"], bili_jct=params["bili_jct"],
                            buvid3=params["buvid3"])  # 生成一个 Credential 对象
    message = user.User(uid=uid, credential=credential)
    return message


"""如果想调用大佬的库可以直接使用这个方法"""


def get_data_info(uid):
    data_info = reobj(uid)
    up_data_info: dict = sync(data_info.get_relation_info())
    return up_data_info


# 直接通过拼接请求头来请求b站
def get_relation_info(uid, httpip):
    headers = getHeaders()
    data_list = getWtsAndW_rid(headers)
    wts = data_list[0]
    w_rid = data_list[1]
    proxys = {'http': f'{httpip}'}

    url = f"https://api.bilibili.com/x/relation/stat?vmid={uid}&web_location=333.999&w_rid={w_rid}&wts={wts}"
    # res1 = requests.get(url2, headers=headers).json()
    response1 = requests.get(url, proxies=proxys, headers=headers, timeout=random.uniform(0.3, 1)).json()  # 使用代理IP
    print(response1)
    fol = response1["data"]["follower"]
    print(f"粉丝数为---{fol}")
    return fol


list =[912, 20000905, 40000944, 60000945, 80000964, 100000963, 120000989, 140000994, 160000897, 180000899, 200000944, 220000875, 240000963, 260000984, 280000988, 300000941, 320000898, 340000940, 360000947, 380000965, 400000967, 420000990, 440000990, 460000900, 480000896, 500000945, 520000943, 540000958, 560000961, 580000993, 600000993, 620000898, 640000898, 660000944, 680000945, 700000964, 720000963, 740000984, 760000991, 780000900, 800000899, 820000945, 840000948, 860000963, 880000968, 900000993, 920000990, 940000898, 960000899, 980000943, 0, 20000000, 40000000, 60000000, 80000000, 100000000, 120000000, 140000000, 160000000, 180000000, 200000000, 220000000, 240000000, 260000000, 280000000, 300000000, 320000000, 340000000, 360000000, 380000000, 400000000, 420000000, 440000000, 460000000, 480000000, 500000000, 520000000, 540000000, 560000000, 580000000, 600000000, 620000000, 640000000, 660000000, 680000000, 700000000, 720000000, 740000000, 760000000, 780000000, 800000000, 820000000, 840000000, 860000000, 880000000, 900000000, 920000000, 940000000, 960000000, 980000000]
# 定义一个函数，每个线程将执行此函数
def process_numbers(start, end, i, pro):
    global lock
    conn = pool.connection()  # 获取链接
    cursor = conn.cursor()
    for number in range(int(start), int(end)):
        time.sleep(random.uniform(0.1, 0.2))
        list[i] = int(list[i]) + 1
        print(list)
        # 这里可以执行任何需要的操作，例如打印数字
        httpip = random.choice(pro)
        try:
            follower: int = get_relation_info(number, httpip)
            if follower >= 10000 and follower is not None:
                values = (number, follower)
                sql = f"insert into screen_up(uid,follower) values{values}"
                cursor.execute(sql)  # 执行
                conn.commit()
                print("写入成功!!!!")
            else:
                print(f"-----{number} ---不满足")
            with lock:
                print(number)
        except Exception as e:
            print(e)
            continue

        # 划分数字范围到各个线程
        # 关闭连接
    cursor.close()
    conn.close()


# 相当于主函数,用来开启多线程的
def partition_and_process(num_threads, numbers_per_thread, list1: list):
    threads = []
    for i in range(num_threads):
        start = i * numbers_per_thread
        end = (i + 1) * numbers_per_thread
        if i == num_threads - 1:  # 最后一个线程处理剩余的数字
            end = total_numbers + 1
        list.append(start)
        t = threading.Thread(target=process_numbers, args=(list[i], end, i, list1))  # list[i]是开始的地方

        # if len(list) == 50:
        #     for i in range(100):
        #         print(list)

        threads.append(t)
        t.start()

        # 等待所有线程完成
    for t in threads:
        t.join()

    # 开始执行多线程处理


# partition_and_process(num_threads, numbers_per_thread)

# 搞个方法用来测试咱们的ip是否能用

if __name__ == "__main__":
    list1 = return_proxy_list()
    partition_and_process(num_threads, numbers_per_thread, list1)
