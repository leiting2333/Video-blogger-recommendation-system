import json
import sys
import numpy as np
from sklearn.naive_bayes import MultinomialNB
import itertools

'''
该方法用于列出所有排列可能
career=["公务员", 
"事业单位工作人员", 
"专业技术人员", 
"生产加工制造人员",
 "农村及农业人员", 
 "军人(军人,武警)", 
 "商业,服务行业人员", 
 "学生", 
 "离退休人员", 
 "全职家庭人员(如全职主妇)", 
 "自由职业", 
 "无职人员"]
'''



# 假设的偏好分配函数
def assign_preference(age, gender, occupation):
    # 基于年龄的偏好
    if age < 10:
        if gender == 0:  # 男性
                return np.random.choice(
                    ["动画", "国创", "音乐",  "游戏", "知识", "科技", "运动", "汽车", "生活", "美食", "电影",
                     "鬼畜",
                     "资讯", "娱乐", "影视", "纪录片", "动物圈"])
        elif gender == 1:  # 女性
            return np.random.choice(["动画", "国创", "音乐", "舞蹈", "知识", "运动", "生活", "美食", "电影", "时尚",
                                     "娱乐", "影视", "动物圈", "电视剧"])

    elif age < 30:
        if gender == 0:  # 男性
                return np.random.choice(
                    ["动画", "国创", "音乐", "游戏", "知识", "科技", "运动", "汽车", "生活", "美食", "电影",
                     "鬼畜",
                     "资讯", "娱乐", "影视", "纪录片", "动物圈"])
        elif gender == 1:  # 女性
            return np.random.choice(["动画", "国创", "音乐", "舞蹈", "知识", "运动", "生活", "美食", "电影", "时尚",
                                     "娱乐", "影视", "动物圈", "电视剧"])

    elif age < 60:
        if gender == 0:  # 男性
                return np.random.choice(
                    ["音乐", "游戏", "知识", "科技", "运动", "汽车", "生活", "美食", "电影",
                     "资讯", "影视"])
        elif gender == 1:  # 女性
            return np.random.choice(["动画", "国创", "音乐", "舞蹈", "知识", "运动", "生活", "美食", "电影", "时尚",
                                     "娱乐", "影视", "动物圈", "电视剧"])
    elif age <= 120:
        if gender == 0:  # 男性
                return np.random.choice(
                    ["音乐",  "知识", "科技", "运动", "汽车", "生活", "美食", "电影",
                     "资讯", "影视"])
        elif gender == 1:  # 女性
            return np.random.choice(["动画", "国创", "音乐", "舞蹈", "知识", "运动", "生活", "美食", "电影", "时尚",
                                     "娱乐", "影视", "动物圈", "电视剧"])
        # 如果没有明确的偏好，则使用基于年龄的偏好



def getList():
    # 假设年龄范围是0-24岁
    zones = ["动画", "国创", "音乐", "舞蹈", "游戏", "知识", "科技", "运动", "汽车", "生活", "美食", "电影", "鬼畜",
             "时尚",
             "资讯", "娱乐", "影视", "纪录片", "动物圈", "电视剧"]
    ages = np.arange(12)  # 生成0到11的整数数组
    genders = [0, 1]  # 性别只有两种可能
    occupations = np.arange(12)  # 职业有0到11共12种可能
    # 使用itertools.product生成所有可能的组合
    combinations = list(itertools.product(ages, genders, occupations))
    #将所有可能的数据转二维数组格式
    combinations_array = np.array(combinations, dtype=object)
    #输出遍历的所有可能
    print(combinations_array)
    #用于生成每个用户喜欢的类型数据.
    preferences = []#所有类型最后喜欢的分区类型.
    re_list=[]
    for combo in combinations_array:
        age, gender, occupation = combo
        #        preference = zones.index(assign_preference(age, gender, occupation))
        string= assign_preference(age, gender, occupation)
        preference = zones.index(string)
        preferences.append(preference)
        # 打印所有组合
    # 你可以创建一个对象数组来存储元组
    re_list.append(combinations_array)
    re_list.append(preferences)
    print(re_list[0])
    print(re_list[1])
    return re_list


# 假设X是特征矩阵，每行表示一个用户的特征向量，Y是目标变量，每个元素表示用户的喜好类别
# 假设有5个用户的数据
def getLikeList(param):
    #视频分类的类别
    zones = ["动画", "国创", "音乐", "舞蹈", "游戏", "知识", "科技", "运动", "汽车", "生活", "美食", "电影", "鬼畜",
             "时尚",
             "资讯", "娱乐", "影视", "纪录片", "动物圈", "电视剧"]
    re_list=[]
    re_list=getList()#模拟288个用户的特征集
    #每个特征集所偏好的视频类别集合
    stubborn_y=[5, 12, 6, 18, 14, 5, 5, 5, 0, 4, 9, 10, 7, 1, 16, 10, 18, 13, 11, 11, 1, 13, 0, 2, 17, 11, 14, 7, 8, 9, 5, 9, 5, 4, 5, 9, 7, 13, 16, 0, 15, 5, 16, 0, 1, 11, 3, 7, 5, 17, 6, 7, 11, 8, 18, 18, 9, 12, 5, 14, 5, 10, 19, 7, 7, 15, 2, 1, 13, 2, 0, 2, 2, 8, 17, 0, 9, 2, 10, 16, 4, 5, 17, 5, 18, 7, 15, 16, 15, 1, 3, 10, 7, 10, 0, 16, 6, 15, 17, 18, 10, 10, 1, 18, 18, 6, 12, 8, 10, 18, 7, 3, 13, 19, 2, 16, 19, 5, 11, 9, 10, 14, 5, 10, 0, 11, 14, 8, 14, 17, 17, 18, 5, 9, 1, 11, 2, 7, 0, 16, 16, 3, 1, 9, 6, 9, 10, 10, 14, 12, 6, 1, 10, 6, 15, 10, 10, 7, 10, 0, 13, 2, 18, 16, 19, 0, 15, 13, 17, 6, 14, 4, 8, 10, 6, 7, 15, 1, 11, 9, 9, 5, 7, 13, 7, 10, 18, 9, 5, 5, 13, 2, 0, 6, 0, 11, 10, 18, 2, 1, 17, 1, 14, 5, 1, 3, 16, 16, 11, 10, 11, 3, 9, 15, 5, 19, 7, 11, 1, 4, 5, 11, 4, 4, 8, 8, 11, 8, 3, 0, 16, 10, 18, 2, 19, 2, 19, 16, 3, 2, 10, 4, 17, 10, 0, 10, 11, 10, 18, 8, 10, 8, 9, 5, 7, 0, 9, 2, 15, 18, 3, 5, 1, 2, 12, 2, 4, 11, 6, 10, 8, 10, 0, 8, 6, 18, 10, 2, 13, 7, 9, 7, 11, 5, 15, 2, 0, 15]
    X = np.array(re_list[0])  # 示例的用户特征向量，最后一列是职业信息
    Y = np.array(stubborn_y)  # 示例的目标变量（用户的喜好类别）
    # 创建多项式朴素贝叶斯分类器对象
    model = MultinomialNB()
    # 使用训练数据对模型进行训练
    model.fit(X, Y)
    # 假设有新用户的特征向量X_new，包含年龄、性别、职业信息
    X_new = np.array([param])  # 年龄20-30岁，男，公务员
    # 使用训练好的模型进行预测
    Y_new_pred_proba = model.predict_proba(X_new)
    #输出偏好
    values=Y_new_pred_proba[0]
    print("新用户对每个分区的喜欢程度的概率值：")
    print(Y_new_pred_proba)  # 输出预测结果
    # 步骤2-4：找到最大的三个值及其索引
    indices_with_values = sorted(enumerate(values), key=lambda x: x[1], reverse=True)
    top_three = indices_with_values[:3]

    # 提取索引和值
    top_indices = [index for index, value in top_three]
    top_values = [value for index, value in top_three]

    # 步骤5：使用索引从内容列表中获取对应的内容
    top_contents = [zones[index] for index in top_indices]


    return top_three


if __name__ == '__main__':

    str = sys.argv[1]
    str2 = sys.argv[2]
    str3 = sys.argv[3]

    # 去掉开头和结尾的方括号
    python_string =json.loads(str+str2+str3)    # 使用切片操作
    # 将字符串按逗号分割成子字符串列表
    # substrings = python_string.split(", ")  # 注意逗号后面有一个空格
    # # 将子字符串列表转换为整数列表
    # int_list = [int(s) for s in substrings]

    re_msg=getLikeList(python_string)

    print(json.dumps(re_msg))

