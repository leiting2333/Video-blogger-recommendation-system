from bilibili_api import user
from bilibili_api import Credential, sync
import requests

params = {
    "sessdata": "0dd148fd%2C1725279771%2C6acc3%2A32CjCqI4K11XZ_5bRScYFS1rAp1idzvy7s1rfZuqu5-bOqVR32IekPtQn5Yb9JN-MeYLISVm5HMEtsbEQxeDdxN3VIM1JiTXY2VEpVRzVzYW9QbUxleFhhRHlXWmNMMW1EVFBvZkRKSXJUTkFCclZDX2R2LUlPeVRFcFVtUDVjcU9BeWNDanBuWGlnIIEC",
    "bili_jct": "a6ff01692a831ed38baecd1161d576bd",
    "buvid3": "7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc",
}
credential = Credential(sessdata=params["sessdata"], bili_jct=params["bili_jct"],
                        buvid3=params["buvid3"])  # 生成一个 Credential 对象
uid = 4659656
message = user.User(uid=uid, credential=credential)


def request_bd():
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0",
        #"Cookie":"__gads=ID=3a6f2ed66f273335:T=1709867666:RT=1710250497:S=ALNI_Mbn1qdn5cZTzUos3W5s6m_64SH3jQ; __gpi=UID=00000d2c443ee1af:T=1709867666:RT=1710250497:S=ALNI_MZch8QvQDCQhL0SO48lGUDLtQNgSQ; __eoi=ID=9eec2ad09dfd1a85:T=1709867666:RT=1710250497:S=AA-Afjb4ePcDojdRz9xdqSgdGwrE",


    }

    url = "http://www.spiderbuf.cn/s01/"

    proxies = {
               'https': '58.221.40.175:80'
               }
    try:
        response = requests.get(url, headers=headers, proxies=proxies,timeout=2)
        if response.status_code == 200:
            print(response.text)
        else:
            print(f"代理不可使用")
    except Exception as e:
        print(e)

request_bd()

def get_user_info1():  # 获取用户基本信息
    msg = sync(message.get_user_info())
    print(msg)
