import pymysql
conn = pymysql.connect(host='127.0.0.1', user='root', password='123456', port=3306, database='bilibili')
# 写入数据库
msg = {'mid': 423895, 'name': '怕上火暴王老菊', 'sex': '保密',
       'face': 'https://i1.hdslb.com/bfs/face/c707dbb7fba4c5184b587024c3ac681b3f5c7c12.jpg', 'face_nft': 0,
       'face_nft_type': 0, 'sign': '微勃er：weibo.com/573244552\n\n', 'rank': 10000, 'level': 6, 'jointime': 0,
       'moral': 0, 'silence': 0, 'coins': 0, 'fans_badge': True,
       'fans_medal': {'show': False, 'wear': False, 'medal': None},
       'official': {'role': 1, 'title': 'bilibili 2022百大UP主、知名UP主', 'desc': '', 'type': 0},
       'vip': {'type': 2, 'status': 1, 'due_date': 1727193600000, 'vip_pay_type': 1, 'theme_type': 0,
               'label': {'path': '', 'text': '年度大会员', 'label_theme': 'annual_vip', 'text_color': '#FFFFFF',
                         'bg_style': 1, 'bg_color': '#FB7299', 'border_color': '', 'use_img_label': True,
                         'img_label_uri_hans': '', 'img_label_uri_hant': '',
                         'img_label_uri_hans_static': 'https://i0.hdslb.com/bfs/vip/8d4f8bfc713826a5412a0a27eaaac4d6b9ede1d9.png',
                         'img_label_uri_hant_static': 'https://i0.hdslb.com/bfs/activity-plat/static/20220614/e369244d0b14644f5e1a06431e22a4d5/VEW8fCC0hg.png'},
               'avatar_subscript': 1, 'nickname_color': '#FB7299', 'role': 3, 'avatar_subscript_url': '',
               'tv_vip_status': 0, 'tv_vip_pay_type': 0, 'tv_due_date': 1625846400,
               'avatar_icon': {'icon_type': 1, 'icon_resource': {}}},
       'pendant': {'pid': 0, 'name': '', 'image': '', 'expire': 0, 'image_enhance': '', 'image_enhance_frame': '',
                   'n_pid': 0}, 'nameplate': {'nid': 8, 'name': '知名偶像',
                                              'image': 'https://i2.hdslb.com/bfs/face/27a952195555e64508310e366b3e38bd4cd143fc.png',
                                              'image_small': 'https://i2.hdslb.com/bfs/face/0497be49e08357bf05bca56e33a0637a273a7610.png',
                                              'level': '稀有勋章', 'condition': '所有自制视频总播放数>=100万'},
       'user_honour_info': {'mid': 0, 'colour': None, 'tags': [], 'is_latest_100honour': 0}, 'is_followed': True,
       'top_photo': 'http://i2.hdslb.com/bfs/space/cb1c3ef50e22b6096fde67febe863494caefebad.png', 'theme': {},
       'sys_notice': {}, 'live_room': {'roomStatus': 1, 'liveStatus': 0,
                                       'url': 'https://live.bilibili.com/1030?broadcast_type=0&is_room_feed=1',
                                       'title': '八点了',
                                       'cover': 'http://i0.hdslb.com/bfs/live/3e052cdf9ec7d6217a449071fd74354be2c245b2.jpg',
                                       'roomid': 1030, 'roundStatus': 0, 'broadcast_type': 0,
                                       'watched_show': {'switch': True, 'num': 36, 'text_small': '36',
                                                        'text_large': '36人看过',
                                                        'icon': 'https://i0.hdslb.com/bfs/live/a725a9e61242ef44d764ac911691a7ce07f36c1d.png',
                                                        'icon_location': '',
                                                        'icon_web': 'https://i0.hdslb.com/bfs/live/8d9d0f33ef8bf6f308742752d13dd0df731df19c.png'}},
       'birthday': '03-22', 'school': None, 'profession': {'name': '', 'department': '', 'title': '', 'is_show': 0},
       'tags': ['看什么看', '没见过帅哥', '什么你见过', '哦原来说我', '原谅你了'],
       'series': {'user_upgrade_status': 3, 'show_upgrade_window': False}, 'is_senior_member': 0, 'mcn_info': None,
       'gaia_res_type': 0, 'gaia_data': None, 'is_risk': False, 'elec': {
        'show_info': {'show': True, 'state': 2, 'title': '充电',
                      'icon': 'https://i0.hdslb.com/bfs/garb/item/33e2e72d9a0c855f036b4cb55448f44af67a0635.png',
                      'jump_url': 'https://www.bilibili.com/h5/upower/index?mid=423895&navhide=1&oid=423895'}},
       'contract': {'is_display': False, 'is_follow_display': False}, 'certificate_show': False}


user_info = []  # 用来保存得到的数据
user_info = msg
uid = user_info["mid"]
name = user_info["name"]
sex = user_info["sex"]
face = user_info["face"]
sign = user_info["sign"]
score = user_info["rank"]
level = user_info["level"]
title = user_info["official"]["title"]
if user_info["vip"]["label"]["text"] == 2:
    vip_type = user_info["vip"]["label"]["text"]
else:
    vip_type = "非会员"
if user_info["live_room"]["roomStatus"] == 1:
    live_room = user_info["live_room"]["url"]
else:
    live_room = "暂未开通直播间"
birthday = user_info["birthday"]
school = user_info["school"]
homepage = "https://space.bilibili.com/" + f"{uid}"
#sql = "insert into up_info('uid','name','sex','face','sign','rank','level','title','vip_type','live_room','birthday,school','homepage')values('%d','%s','%s','%s','%s','%d','%d','%s','%s','%s','%s','%s','%s')" % (uid, name, sex, face, sign,rank,level,title,vip_type,live_room,birthday,school,homepage)


values2=(uid, name, sex, face, sign)
sql2 = f"insert into up_info(uid, name, sex, face, sign) VALUES{values2}"
print(sql2)

values = (uid, name, sex, face, sign, score, level, title, vip_type, live_room, birthday, school, homepage)
sql = f"insert into up_info(uid, name, sex, face, sign, score, level, title, vip_type, live_room, birthday, school, homepage) VALUES{values}"
print(sql)
try:
    cursor = conn.cursor(  )  # 启动
    cursor.execute(sql)  # 执行

    conn.commit(  )  # 关闭
except BaseException as e:
    print(e)

pass