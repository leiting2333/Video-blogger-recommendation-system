import random
from typing import Any
import requests
from bs4 import BeautifulSoup

from bilibili.random_headers import getHeaders
from screen_up import reobj
from bilibili.tools.tools import getWtsAndW_rid

"""用来请求提供免费ip地址的网站header"""
headers = {
    "Accept": "application/json, text/javascript, */*; q=0.01",
    "Accept-Encoding": "gzip, deflate, br",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8,ja;q=0.7,zh-TW;q=0.6",
    "Content-Length": "607",
    "Content-Type": "application/json;charset=UTF-8",
    "Origin": "https://webpage.qidian.qq.com",
    # "Connection": "keep-alive",
    # "Cookie": "Hm_lvt_b9de64757508c82eff06065c30f71250=1709359661,1709453208,1709775038; Hm_lpvt_b9de64757508c82eff06065c30f71250=1709775038; ASP.NET_SessionId=rpbv1smlqlagdy3q0tgxb2sv; chl=key=feigua2; FEIGUADY=24F5F6914C51DA2BD70C8CB5BB83A150473164311B0D4BD64D419A02F22496165A24273B46BC4AEF7F002FB35E5B24D30052A2B5555AE9411501E7E134294A69F7F1B9C0F959997D1034FCD8F851BF4BFE6927EA6551438833CC723FEE33CD9FB06A612DB51509F36B1DDD53BCA4798939239272C8C04368F14FC6CF44EEDB8ECAD4A321B3DD6645FBAD97661D961C39051192B6FC3C5BD6151CFA3A77AAE0C9C4B20B7DC4C94C5D7156668BC4383CF363BAA21D445D7A5C5861CDDC652ED0A569CE8E71B99BD30163B7AEB6B2141114; 0d7771b40b7dd1c5094f3119afc6dab8=11c014ebad67002f9ba5bc3a4abd90b606fcb8fa9e6d88ef3c6eedc5dcd2757550b28dec06befc51ef302e428d536df2c2384692dbb58d8f158e0baa415f552e40b7ca7338ade2aee197795a8211ff3209cb463e2dc028351db00f1e00a5003cd1d1fb5f6c43dc0cb032aa8071d3401c; body_collapsed=0; tfstk=eVnkDxxJp4z7BgSsHbEWmPpiqv8Ye_ZQwXIL9kFeuSPjvTHedMxn_Av78QMKikDIL7oz4gh38blKyydSvjxnifuR9DDCxJkEOLNpFEHSFkZe6CEHXYM5d6-GUhKumxigYCd9DhhYJNrEyxKlUMz55gap5mTL75XTFXhnOLaY_YPreYn2wz_SUSjFYm00r5STiMSEm8jzCZ7aTcsQ3pnVRwazh-VtOEGfEYth2K9DnNt4z-wWmKvcRwazh-V9nKbNuzybFnf..",
    # "Host": "dy.feigua.cn",
    "Referer": " https://webpage.qidian.qq.com/ ",

    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-origin",
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36",
    "X-Requested-With": "XMLHttpRequest"
}
header = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
    "Cache-Control": "max-age=0",
    "Content-Length": "5607",
    "Content-Type": "application/x-www-form-urlencoded",
    'Cookie': 'Hm_lvt_8ccd0ef22095c2eebfe4cd6187dea829=1709870942; cf_chl_3=69ea606c9d30eb8; cf_clearance=iHHQKespxiQDEOIhor0R9rLosRyLe02CjgYKnZ49l6c-1709876789-1.0.1.1-9LF4ju0.gDguktaxufyp0fW6ajIUqgrRQ_38gRudy0qukH0rwPtafkILER.wj8vq_aZpXNENkDbveSVhDBZZOA; Hm_lpvt_8ccd0ef22095c2eebfe4cd6187dea829=1709878265',
    'Dnt': '1',
    'Referer': 'https://ip.ihuan.me/address/5Lit5Zu9.html',
    'Sec-Ch-Ua': '"Chromium";v="122", "Not(A:Brand";v="24", "Microsoft Edge";v="122"',
    'Sec-Ch-Ua-Arch': '"x86"',
    'Sec-Ch-Ua-Bitness': '"64"',
    'Sec-Ch-Ua-Full-Version': '"122.0.2365.66"',
    'Sec-Ch-Ua-Full-Version-List': '"Chromium";v="122.0.6261.95", "Not(A:Brand";v="24.0.0.0", "Microsoft Edge";v="122.0.2365.66"',
    'Sec-Ch-Ua-Mobile': '?0',
    'Sec-Ch-Ua-Model': '""',
    'Sec-Ch-Ua-Platform': '"Windows"',
    'Sec-Ch-Ua-Platform-Version': '"15.0.0"',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-User': '?1',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0'
}


# 为了请求免费代理网站,这是pages数
def read_pages():
    try:
        pages = []  # 代理IP网页的页数
        with open(r'./httpipcfg.txt', mode='r', encoding='utf-8') as f:  # 代理IP文档存放路径
            content = f.readline()  # 按行读取
            while content:  # 循环最后一句的意义为当content读不到行时停止，这样能一行一行全部读取
                op = content.split("@")
                pages.append(str(op[0]))
                content = f.readline()
        print(pages)

    except Exception as e:
        input('载入代理IP失败，请检查httpipcfg.txt是否正确存在脚本目录！忽略此错误')
        print(e)
    return pages


# 1. 获取代理IP列表,通过解析第三方提供免费代理的网站
def get_proxy_list(list):
    '''
    :param i: 为请求的页码,具体得看网站url结构
    :return: 返回字典列表
    '''
    # 构造请求头，模拟浏览器请求
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36"
    }
    # i=1
    # for i in range(8):

    # 请求代理IP网页
    url = f"https://ip.ihuan.me/address/5Lit5Zu9.html"
    print(url)
    response = requests.post(url, headers=header, timeout=2)
    print(response.status_code)
    if response.status_code != 200:
        print("请求失败")
        print(response.status_code)
        return 0

    # 解析网页获取代理IP列表
    '''
    此处应当对应不同网站进行修改解析逻辑
    '''
    soup = BeautifulSoup(response.text, "html.parser")  # 解析请求到的数据
    proxy_list = []
    table = soup.find("tbody").find_all("tr")
    for tr in table:
        td_list = tr.find_all("td")
        if len(td_list) > 3:
            ip = td_list[0].find_all("a")[1]
            port = td_list[1].text.strip()

            proxy_list.append({
                "ip": f"{ip}:{port}",

            })
    print(proxy_list)
    return proxy_list
""" 以字典形式返回代理的ip的地址,端口,类型"""

#  3验证代理可用性
def get_relation_info(uid, httpip:list):
    global response1
    can_use_list = []
    for i in range(len(httpip)):
        print(f"当前在第---{i}------")
        headers = getHeaders()
        data_list = getWtsAndW_rid(headers)
        wts = data_list[0]
        w_rid = data_list[1]
        proxy={
            "http":f"{httpip[i]}"
        }
        proxys = {
            'http': '60.174.1.165:8089'
        }
        url = f"https://api.bilibili.com/x/relation/stat?vmid={uid}&web_location=333.999&w_rid={w_rid}&wts={wts}"
        # res1 = requests.get(url2, headers=headers).json()
        try:
            response1 = requests.get(url,proxies=proxy,  headers=headers,timeout=random.uniform(0.1,0.2))  # 使用代理IP
        except Exception as e:
            print(e)
            continue
        if response1.status_code!=200:
            print(f"-------{httpip}----代理不可用!")
        else :
            print(response1.json())
            list_can_use=[]
            list_can_use.append(httpip[i])
            append_to_file("can_using_ip", list_can_use)
            print(can_use_list)
    return can_use_list





# 验证文件中ip可用性,懒~
def verify_proxy2(proxy) -> list[Any]:
    '''
    :param proxy: 第二部得到的ip列表
    :return: 返回一个新的ip列表
    '''

    # 构造请求头，模拟浏览器请求
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36"
    }
    # 请求目标网页并判断响应码
    url = "http://books.toscrape.com/"
    can_use_list = []
    for i in range(len(proxy)):
        try:
            proxys = {'http': f'{proxy[i]}',
                      'https': f'{proxy[i]}'}

            response = requests.get(url, headers=headers, proxies=proxys, timeout=0.1)
            print(response.status_code)
            if response.status_code == 200:

                can_use_list.append(proxy[i])
            else:
                print(f"{proxy[i]}代理不可使用")
        except Exception as e:
            print(e)
            continue
    return can_use_list



# 执行写入操作1,这种方式用于写入 ip 端口的格式
def append_to_file(filename, list):
    """
    将文本追加到文件中。如果文件不存在，则创建它。
    :param filename: 文件名
    :param list: 要写入ip列表
    """
    for i in list:
        try:
            # 打开文件以追加模式，如果文件不存在则创建它
            with open("./can_use_ip.txt", 'a') as file:
                file.write(f"{i}" '\n')  # 写入文本并添加换行符
            print(f"文本{i}已成功追加到文件 '{filename}' 中。")
        except IOError as e:
            print(f"发生I/O错误: {e}")
            print(f"{i} ---------- 添加失败")
        except Exception as e:
            print(f"发生未知错误: {e}")
            print(f"{i} ---------- 添加失败")
    print("==========写入成功,好耶!!")


def read_file_ip():
    # 读取代理IP文件并加载到pro列表中
    try:
        pro = []  # 代理IP列表
        with open(r'../file_using/httpipcfg.txt', mode='r', encoding='utf-8') as f:  # 代理IP文档存放路径
            content = f.readline()  # 按行读取
            while content:  # 循环最后一句的意义为当content读不到行时停止，这样能一行一行全部读取
                op = content.split()  # 用op对象存储，把一行切割成数组，去除空格
                if len(op) >= 2:  # 确保op至少有两个元素
                    pro.append(str(op[0] + ":" + op[1]))  # 第一列数据下标为0
                else:
                    print(f"忽略格式不正确的行: {content.strip()}")  # 打印并忽略格式不正确的行
                    break
                content = f.readline()
        print(pro)

    except Exception as e:
        input('载入代理IP失败，请检查httpipcfg.txt是否正确存在脚本目录！忽略此错误')
        print(e)

    return pro
    # 将文本中的非中文移除

    # 程序入口

def proxy_request_bili(uid:int,httpip):
        data_info = reobj(uid)
       # up_data_info: dict = sync(data_info.get_relation_info())
        headers = getHeaders()
        data_list = getWtsAndW_rid(headers)
        wts = data_list[0]
        w_rid = data_list[1]
        url = f"https://api.bilibili.com/x/relation/stat?vmid={uid}&web_location=333.999&w_rid={w_rid}&wts={wts}"
        # res1 = requests.get(url2, headers=headers).json()
        response1: dict = requests.get(url, proxies={'https': str(httpip)}, headers=headers)  # 使用代理IP
        print(response1)

        return response1["follower"]



if __name__ == "__main__":
    # 获取代理IP列表
    # proxy_list = get_proxy_list(1)

    # 验证代理IP可用性
    # valid_proxy_list = link_ip(proxy_list)

    # 读取文件中的ip  验证可用性
    # read = read_file_ip()
    #  proxy_list = verify_proxy2(read)
    #  print(proxy_list)
    list_proxy=[]
    list_proxy=read_pages()
    list_can_use=get_relation_info(423895,list_proxy)
   # append_to_file("can_using_ip",list_can_use)





