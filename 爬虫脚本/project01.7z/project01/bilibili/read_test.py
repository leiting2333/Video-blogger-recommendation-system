import time
def getUidList():
    with open('../file_using/uids.txt', 'r') as file:
        list=[]
        while True:
            line = file.readline().replace("\n", "")
            list.append(line)
            if not line:
                break
        print(list)
        return list


