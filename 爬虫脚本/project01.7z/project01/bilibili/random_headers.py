import random
header=[
  "Opera/8.26.(Windows NT 6.0; nds-DE) Presto/2.9.177 Version/12.00",
  "Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/532.39.2 (KHTML, like Gecko) Version/4.0.2 Safari/532.39.2",
  "Mozilla/5.0 (Windows 98; en-HK; rv:1.9.2.20) Gecko/2020-07-20 11:29:47 Firefox/3.8",
  "Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/4.0)",
  "Opera/8.72.(Windows 98; xh-ZA) Presto/2.9.172 Version/10.00",
  "Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.1; Trident/5.0)",
  "Mozilla/5.0 (Windows; U; Windows NT 5.01) AppleWebKit/533.12.2 (KHTML, like Gecko) Version/4.0 Safari/533.12.2",
  "Opera/8.67.(Windows NT 6.0; or-IN) Presto/2.9.174 Version/11.00",
  "Opera/9.39.(Windows NT 6.2; eo-US) Presto/2.9.177 Version/11.00",
  "Opera/9.91.(Windows 98; Win 9x 4.90; ia-FR) Presto/2.9.167 Version/10.00",
  "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 10.0; Trident/3.1)",
  "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/4.0)",
  "Opera/8.91.(Windows NT 5.1; lo-LA) Presto/2.9.166 Version/12.00",
  "Mozilla/5.0 (Windows NT 5.2; csb-PL; rv:1.9.2.20) Gecko/2012-05-05 21:49:44 Firefox/3.6.20",
  "Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/3.0)",
  "Mozilla/5.0 (Windows 95) AppleWebKit/533.2 (KHTML, like Gecko) Chrome/50.0.867.0 Safari/533.2",
  "Opera/9.50.(Windows CE; eo-US) Presto/2.9.166 Version/11.00",
  "Mozilla/5.0 (Windows; U; Windows 98; Win 9x 4.90) AppleWebKit/531.21.1 (KHTML, like Gecko) Version/5.0 Safari/531.21.1",
  "Mozilla/5.0 (Windows NT 5.0) AppleWebKit/534.2 (KHTML, like Gecko) Chrome/59.0.865.0 Safari/534.2",
  "Mozilla/5.0 (compatible; MSIE 5.0; Windows 95; Trident/5.0)",
  "Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.1; Trident/4.1)",
  "Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 6.2; Trident/3.0)",
  "Mozilla/5.0 (Windows; U; Windows NT 5.01) AppleWebKit/532.38.2 (KHTML, like Gecko) Version/5.0.2 Safari/532.38.2",
  "Opera/9.86.(Windows NT 10.0; zu-ZA) Presto/2.9.163 Version/10.00"
  "Opera/9.81.(Windows NT 5.2; pt-PT) Presto/2.9.169 Version/12.00",
    "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.01; Trident/4.0)",
    "Mozilla/5.0 (Windows; U; Windows NT 10.0) AppleWebKit/532.23.7 (KHTML, like Gecko) Version/5.0.5 Safari/532.23.7",
    "Mozilla/5.0 (compatible; MSIE 5.0; Windows 98; Win 9x 4.90; Trident/4.0)",
    "Mozilla/5.0 (compatible; MSIE 8.0; Windows 98; Trident/5.1)",
    "Opera/8.29.(Windows NT 5.0; mai-IN) Presto/2.9.164 Version/10.00",
    "Mozilla/5.0 (Windows 95; uk-UA; rv:1.9.1.20) Gecko/2012-04-16 04:15:37 Firefox/14.0",
    "Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 10.0; Trident/3.0)",
    "Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 10.0; Trident/3.0)",
    "Mozilla/5.0 (Windows 98) AppleWebKit/536.2 (KHTML, like Gecko) Chrome/38.0.862.0 Safari/536.2",
    "Opera/9.75.(Windows NT 5.1; sat-IN) Presto/2.9.169 Version/11.00",
    "Mozilla/5.0 (Windows NT 5.2; ht-HT; rv:1.9.0.20) Gecko/2021-10-15 22:24:32 Firefox/3.8",
    "Mozilla/5.0 (Windows NT 6.0; mi-NZ; rv:1.9.1.20) Gecko/2021-12-01 20:27:32 Firefox/15.0",
    "Opera/9.27.(Windows NT 5.0; sid-ET) Presto/2.9.167 Version/11.00",
    "Mozilla/5.0 (compatible; MSIE 5.0; Windows NT 6.2; Trident/5.1)",
    "Mozilla/5.0 (Windows; U; Windows NT 5.0) AppleWebKit/533.35.5 (KHTML, like Gecko) Version/5.1 Safari/533.35.5",
    "Mozilla/5.0 (compatible; MSIE 7.0; Windows CE; Trident/3.1)",
    "Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.0; Trident/4.1)",
    "Opera/9.39.(Windows NT 6.2; eo-US) Presto/2.9.177 Version/11.00",
    "Mozilla/5.0 (Windows NT 5.2) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/43.0.813.0 Safari/532.2",
    "Mozilla/5.0 (Windows NT 5.2; csb-PL; rv:1.9.2.20) Gecko/2012-05-05 21:49:44 Firefox/3.6.20",
    "Mozilla/5.0 (Windows NT 5.2; shs-CA; rv:1.9.0.20) Gecko/2017-02-16 06:35:22 Firefox/15.0",
    "Mozilla/5.0 (compatible; MSIE 6.0; Windows CE; Trident/4.0)",
    "Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 4.0; Trident/5.0)",
]
def getHeaders():
    random_data = random.choice(header)
    head={
      "User-Agent":f"{random_data}"
    }
    return head

