import json

def json_writer_dict(json_file_name:str,json_dict:dict):
    with open(json_file_name,'w', encoding='utf-8')as f:
        json.dump(json_dict,f,indent=4,ensure_ascii=False)
