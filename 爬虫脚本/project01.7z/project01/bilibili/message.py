import time

from bilibili_api import user
from bilibili_api import Credential, sync
from file_op import json_writer_dict as json_writer
import pymysql
from up_zone import retureZone
from get_fans_follows import getFansData


class GetMessage:
    # 加判断分区的数据集合，根据up的代表作来判断
    location = ""  # 根据代表做的发布地址代表实际ip地址

    def __init__(self, uid: int, credential: Credential):
        self.uid = uid
        self.credential = credential
        self.message = user.User(uid=uid, credential=credential)
        self.tid_list = []

    def get_user_info1(self):  # 获取用户基本信息
        message = self.message
        msg: dict = sync(message.get_user_info())
        print(msg)
        time.sleep(0.5)
        user_info = []  # 声明，没用到。用来保存得到的数据------该api请求到的数据
        user_info = msg
        uid = user_info["mid"]
        name = user_info["name"]
        sex = user_info["sex"]
        face = user_info["face"]
        sign = user_info["sign"]
        score = user_info["rank"]
        level = user_info["level"]
        title = user_info["official"]["title"]
        if user_info["vip"]["type"] != 0:  # 判断会员类型
            vip_type = user_info["vip"]["label"]["text"]
        else:
            vip_type = "非会员"
        if user_info["live_room"] is not None and user_info["live_room"]["roomStatus"] == 1:  # 判断是否开通直播
            live_room = user_info["live_room"]["url"]
        else:
            live_room = "暂未开通"

        birthday = user_info["birthday"]
        if user_info["school"] == None or user_info["school"]["name"] == "":
            school = "保密"
        else:
            school = user_info["school"]["name"]

        homepage = "https://space.bilibili.com/" + f"{uid}"
        # -----------------一些别的数据，包括ip地址，总播放量，点赞数，代表作分区
        tid = retureZone(self.tid_list)  # 分区
        if self.location != None or self.location != "":
            location = self.location
        else:
            location = "未知"
        list = getFansData(self.uid)
        following = list[2]
        follower = list[3]
        values = (
        uid, name, sex, face, sign, score, level, title, vip_type, live_room, birthday, school, homepage, following,
        follower, str(tid), location)
        values_two = (
        name, sex, face, sign, score, level, title, vip_type, live_room, birthday, school, homepage, following,
        follower, str(tid), location, uid)
        sql = f"insert ignore  into up_info_bak(uid, name, sex, face, sign, score, level, title, vip_type, live_room, birthday, school, homepage,following,follower,tid,location) VALUES{values}"
        sql_two = "UPDATE up_info_bak SET `name` = '{}',`sex` = '{}' ,`face` = '{}' ,`sign` = '{}' ,score = '{}' ,level = '{}' ,title = '{}' ,vip_type = '{}' ,live_room = '{}' ,birthday = '{}' ,school = '{}' ,homepage = '{}' ,following = '{}' ,follower = '{}' ,location = '{}' WHERE uid = '{}'".format(
            name, sex, face, sign, score, level, title, vip_type, live_room, birthday, school, homepage, following,
            follower, location, uid)
        sql_list = []
        sql_list.append(sql)
        sql_list.append(sql_two)
        return sql_list

    # 用来将数据写入json文件方便观看
    def changeJson(self, name: str, dict: dict):  # 写进json文件
        json_writer(json_file_name=f"./{name}.json", json_dict=dict)

    def get_masterpiece(self):  # 获得up的著名的一些视频应该先把这个数据写入数据库，然后用户基本信息才能获得ip地址，分区等数据
        top_video = self.message  # 获得user对象
        msg: list = sync(top_video.get_masterpiece())
        print("===========")
        # print(msg)
        if len(msg) > 0:
            sql_list = []
            for i in range(len(msg)):
                self.tid_list.append(msg[i]["tid"])  # 视频分类tid
                video_picture = msg[i]["pic"]  # 视频封面
                video_title = msg[i]["title"]  # 视频标
                video_time = msg[i]["pubdate"]  # 发布时间
                if msg[i]["copyright"] == 1:
                    video_copyright = "原创"
                else:
                    video_copyright = "转载"
                # 播放量，弹幕数量暂定--
                video_viewing_frequency = msg[i]["stat"]["view"]  # 视频播放量
                video_danmaku = msg[i]["stat"]["danmaku"]  # 弹幕数量
                video_reply = msg[i]["stat"]["reply"]  # 评论数
                # self.location= msg[i]["pub_location"]  # 视频发布地址
                video_like = msg[i]["stat"]["like"]  # 点赞
                video_coin = msg[i]["stat"]["coin"]  # 投币
                video_favorite = msg[i]["stat"]["favorite"]  # 收藏
                video_short_link_v2 = msg[i]["short_link_v2"]  # 评论数
                # ------------------
                values = (
                self.uid, video_title, video_viewing_frequency, video_danmaku, video_time, video_picture, video_like,
                video_coin, video_favorite, video_short_link_v2)
                sql = f"insert ignore into top_video_info_bak2(uid,video_title, video_viewing_frequency, video_danmaku, video_time, video_picture, video_like, video_coin,video_favorite, video_short_link_v2)values{values}"
                # print(f"当前获得代表作的博主uid为{-----self.uid}")
                sql_list.append(sql)
            return sql_list
        else:
            print("------暂无代表作----")
            return []

    # 获取用户关系信息（关注数，粉丝数，悄悄关注，黑名单数）
    def get_relation_info(self):
        data_info = self.message
        up_data_info: dict = sync(data_info.get_relation_info())
        print(up_data_info)

    # 获取 UP 主数据信息（视频总播放量，文章总阅读量，总点赞数）

    def get_up_stat(self):
        data_info = self.message
        try:
            up_data_info: dict = sync(data_info.get_up_stat())
            print(up_data_info)
        except Exception as e:
            print(f"-------没获取到这个人{self.uid}--的总播放量和总likes++++++++++++++")
            print(e)
            return 1
        return up_data_info

    def get_videos(self, i):
        data_info = self.message
        try:
            up_data_info: dict = sync(data_info.get_videos(0, i, 30, ""))
        except Exception as e:
            print(f"-------这个人好像没了++++++++++++++")
            return e
        return up_data_info

    def get_top_videos(self):
        data_info = self.message
        up_data_info: dict = sync(data_info.get_top_videos())
        return up_data_info

    def get_media_list(self):
        data_info = self.message
        up_data_info: dict = sync(data_info.get_media_list())
        return up_data_info


def test_mother():
    params = {
        # "sessdata": "e1d31719%2C1725038688%2C4b378%2A32CjB7UYFhUpbXtX_zRW2ifJwC2UwKiMK2-2VQi9N8pduvbuQiTPgb_mon2voTAEWPVzsSVjJzeEM4eExvYUdtLTdWODVtTy1CeVBROGtEVWxQNkk3OXBkOUNjUFpfRHBpcVZJRS1iUTFwd045Q1FIZVNrOHFVVXlkcmwzWmZVNG5HZ2RqQ1ktSFVRIIEC",
        # "bili_jct": "100c4689af4dd02381b10cbd725c3a8e",
        "buvid3": "7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc"
    }
    # sessdata=params["sessdata"], bili_jct=params["bili_jct"],

    # message.get_user_info1()
    # stats= message.get_up_stat()
    # print(stats)
