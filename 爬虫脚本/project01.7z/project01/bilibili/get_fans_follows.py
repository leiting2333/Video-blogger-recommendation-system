import requests
from tools.tools import getWtsAndW_rid
from random_headers import  getHeaders
import time

def getFansData(uid:int):
    data_list=[]
    headers=getHeaders()
    data_list=getWtsAndW_rid(headers)
    wts=data_list[0]
    w_rid=data_list[1]
    #url1=f"https://api.bilibili.com/x/space/wbi/acc/info?mid={uid}&token=&platform=web&web_location=1550101&{result}&wts={wts}&w_rid={w_rid}"
    url2=f"https://api.bilibili.com/x/relation/stat?vmid={uid}&web_location=333.999&w_rid={w_rid}&wts={wts}"
    url3=f"https://api.bilibili.com/x/space/upstat?mid={uid}&web_location=333.999"
    res1=requests.get(url2,headers=headers).json()

    #res2=requests.get(url3,headers=headers).json()
    following=res1["data"]["following"]
    follower=res1["data"]["follower"]
    # view=res2["data"]["archive"]["view"]
    # likes=res2["data"]["likes"]
    data_list.append(following)
    data_list.append(follower)
    # data_list.append(likes)
    # data_list.append(view)

    print(data_list)
    return data_list



