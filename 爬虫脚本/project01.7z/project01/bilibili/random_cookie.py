import os
import hashlib
import base64
import time
import random

# 初始的params列表
params = [
    # ... (这里省略了原有的数据，以保持示例简洁)
{'sessdata': '8TZZnbX1Pkxuszlq/VmdYw%2C1709698858%2Ce13075dc4de3afaa4826c140b2d86afd%2A32Cjb4e85b9c32918ea1b7a4df81696c2883IIEC', 'bili_jct': 'nlgtam80v0dlmiieqy0l6mix9fiv2q3r', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'HXE0k8QMpp/9+b67twcIhQ%2C1709698858%2C69fe7e1ea85fefb83cd952e844761408%2A32Cj00e74b32209f05bc69a26c9bb33dce7fIIEC', 'bili_jct': 'yjyi22002na75p66mw1s0lvrknk9g9ra', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'NfUpyRLHGf58t8AJ5oHgfw%2C1709698858%2C81c297eb442cbb49ef42df4f470e9dc9%2A32Cj8231544335589bb38ebe76f07492d61cIIEC', 'bili_jct': '5xepoxmjkgcdc7pqn6f8fyhnbbcwtx6d', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': '51C0u5NniYtqvXXW2e5Urg%2C1709698858%2C418710277fda26d6eadb690376f3b132%2A32Cj9772bf9ffebdf62b59ff150d7c294d5bIIEC', 'bili_jct': 'l21gmhwmodjloaz8vwoe9zk3n7lmrihy', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'zqOrIeVK2qrFrpcRCw6Hog%2C1709698858%2C8e7b29f1ccbc1d8c9fc9ba8c52f11326%2A32Cje717c4e936a853edfc95de6d929cb4d0IIEC', 'bili_jct': 'thpu27u9d0cq8amd19z9b5py3b1nrlng', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'hpV65PyuK7PoZDpGsLRq5g%2C1709698858%2C799e245a267e9040d285387b94524852%2A32Cje36046c7cdeaaa00a77d85ca1a5fc1ecIIEC', 'bili_jct': 'le09404m426pxr6zhm3rva8njaq0jogu', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'eNtsHvNG61FLWoW5RLNO/w%2C1709698858%2Ce508f123519429b95146259c45feb6ed%2A32Cj69d0c9625cc5714cbdf1bde2b7656e9dIIEC', 'bili_jct': '73bltn7jpvjuli4rfnuuhsse80zavikr', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'Gc0QfKUzrllZ93R/4q4+iQ%2C1709698858%2C6f1135a70190eb1865c16b79a334487d%2A32Cje0ff9dfe651643d925bcad0cd1a8c24eIIEC', 'bili_jct': '40p7o2629ogr6xaxp7im6t5io269axe4', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'y7TcF9XGxJ+U5zL8sH+Srw%2C1709698858%2Cd2ea8e1016ad031d68d086c5dd9e2cc3%2A32Cj18ba95c1cdd81f40f60d6d5c03f1d6f4IIEC', 'bili_jct': 'qz25xd6hsspixju3zlxz10svexb48mo2', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'Wj7C6IJmN8dn1WyEiWKTXg%2C1709698858%2C4b83afc923928ca51b17f160eb4a44cd%2A32Cj91a6b9804a26800eea91132e60089bb3IIEC', 'bili_jct': '4ff2m83o3md2chc6m4hmnt7ovji67vgc', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'KyXRXd9ySp6Mbhyi2d5T9A%2C1709698858%2C97a217183e75d2700ac5b7f8f2cdf386%2A32Cj27015f4359cfdbacc7761a52a022bbb9IIEC', 'bili_jct': 'tjxktz3uuykvvvf39x1vcm3zpygy962k', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': '3dyWgwAxVWzFqT/JqQCuMw%2C1709698858%2Ce03c461696c0994536220ba3f3e5752f%2A32Cj70d5241e7b806a73b6d9e118cb366506IIEC', 'bili_jct': '0x7kyog3zetb4pr80c9yrxad6g9vo17o', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'wavHnmAP2fE+4cSPcZX9SA%2C1709698858%2C51014a60b249352292f30c1000d69064%2A32Cj42bbe7f202843eff375c102cf66e21ffIIEC', 'bili_jct': 'swwt4nk5lfpt4xjs0speqgzsr18vqevy', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'RuNBs9EKbOThVjbBYuYaYA%2C1709698858%2Cf3fd5c4e42e215a392e1d74374808401%2A32Cj4f5b6a198eeb63f27c5809dfbb5f1e44IIEC', 'bili_jct': 'tbchtzdo27mg4kpbz5lld31ujmea2apq', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'kz43q1mMNgLcgP9xpQs8Sw%2C1709698858%2C5e3f216a3cbf0d164cd97f91f15ac0e0%2A32Cj75ff88913dfe381f2665361551fcc11eIIEC', 'bili_jct': 'iyhjqzv5onwrqnb9j26qbsu9xpz9sf8w', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'hcH6BOz9oR7kEZNm6Tm/4A%2C1709698858%2C77531fa3a9e7720e080db65a9aa84934%2A32Cjdb187f717c54cf298f0132662ba538acIIEC', 'bili_jct': 'lndg9gxuumtuf91t6zswaltd5e0mbk0l', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'GSn0XpzCZp5w5ZEymWmuBQ%2C1709698858%2C85de3d99baffec7e9154b0caff57be4e%2A32Cj1692490178581a0ffe6d4580dff2fda0IIEC', 'bili_jct': 'g48gk2vsjy1mfn6by149ydf827ghwkdn', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'kzSJCqNjyxJyUDkvZW0Irg%2C1709698858%2C2dd8a9da5bdb30e01f60d7ee43d585d1%2A32Cj0d9d736c93d1a6a92108f996a24b5c01IIEC', 'bili_jct': 'zkzgpz2r3jl6qctnqdj88m48fv05pgkg', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 's/YgRYtRwdqHAPebkMPVTQ%2C1709698858%2Cde702e0d0d13b6bb5f0deac55aa160df%2A32Cjc68a33c00b46b16f2de8e1e598385a5fIIEC', 'bili_jct': 'qsjg7fiyed4pgwudd00kxtpsg96ttlqh', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': '9n4Hsguk4/KbwDL6gwYXqA%2C1709698858%2C1e79a1f41037a5d3229751954832781e%2A32Cj4b5e8e93ee28a5cf4892c71ca87c4027IIEC', 'bili_jct': '6cq2vd22leixy6nnvmumm6tgmppgfala', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'fPjEOfAXB8H8dxbQB5VFVA%2C1709698858%2C41719d891ed0acb5af04a0b662ed9e2e%2A32Cjd5a4d10a29a82120b61136343c14963aIIEC', 'bili_jct': 'bnw67izr5xm3riz59430obf50b0bobyz', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'UKxHdaaPzdCT2Eld6BRS0A%2C1709698858%2C9f344d60c9e221d4fddb2308e44d1954%2A32Cj9a38e38e6a999e67430988417bbb537eIIEC', 'bili_jct': 'mr81q4u48l7wh3jnz7hz1gkzks82l9xh', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'y3GwQu3twv0lvslLWbhKHg%2C1709698858%2C8e5b729866724840942e7a87a7f24073%2A32Cj87b3cb61b83ab2e70ddd8e7d5a51afbeIIEC', 'bili_jct': '4ssf618f89gpyfi3nwp4la6947j4qatx', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'VUZh1KCjorUEO0qNGjX7qg%2C1709698858%2C70c046586ac41ebd0a5a6b79e5666585%2A32Cj55afd2373fc21ee29b2fbf4e25c44d27IIEC', 'bili_jct': 'pupjyv6gyta461nj6vjz9anwj591em7o', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': '//yVMGcyIe8IogSytkHyOw%2C1709698858%2Cb4ac0d15b15f0e980b35f10508eab30c%2A32Cjb020c6abcc0dc9d40e829ae815e1ca87IIEC', 'bili_jct': 'ihars3hce4ir1g76hxfpxuqoolw00e6q', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'aats89L1EcEaqDL/1CRXpg%2C1709698858%2C39b25aa7acbaa74a40b0b391a24968c8%2A32Cj06020488a70f21817984992d196ecb12IIEC', 'bili_jct': 'v5vi97empkdnnpgqi0x0tww9zl5ue5cs', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'L6uSG2JSszRQXtGUaytS2g%2C1709698858%2C6a83600865972c4d44a498520a6dc7f8%2A32Cj9ef2f0e0ec08338efe7a70adae6b530cIIEC', 'bili_jct': 'n4vw1ryo9sxn2vykegr8xz0xpav1caf4', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': '3I6jH5CioV158/FqZ3fNyQ%2C1709698858%2Cdc35238691117b8efc6b135342a40239%2A32Cj5e64401356b14d35b6bfff62c22dd5a2IIEC', 'bili_jct': 'v1pple1tuqyztu0k1i0i6efmuwrvb99w', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'I7N09lQQP35NbetCRX3aLg%2C1709698858%2C60f242d2e78f3f0b98ec62791d08047f%2A32Cjba270a4af977449481fb84df60bd0c30IIEC', 'bili_jct': 'zzudxdj05vrtt1awncbbo0j6j5t899sd', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'ge03JD/LEzICdNTZjywETg%2C1709698858%2Cc482e853e2b1e73c0d4a2f22f1b53714%2A32Cj01b622fbbea7d03f15404cb94d633991IIEC', 'bili_jct': '2luwudmwkxd9mv4qvcnkx8txeswm0cy2', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'F6rVJQ+TTKBRrX6gnXSsIg%2C1709698858%2Cb9b153a9404bfa061cf02d7389c1b26b%2A32Cj65f2f528f7597423050e121512ef2863IIEC', 'bili_jct': 'fi5ixr2xncrnypfmgf5rdd8vffusfqxu', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': '3nsCJadQOzZCTpNzJ4BMug%2C1709698858%2C54434f8fb900762614f5c8d30b799956%2A32Cj133c528fc43ce536e548b8c1df24fd99IIEC', 'bili_jct': '8z1fzljfe87wbebzwtj3dq8mkr4ybpol', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'K5Qva9ay+KmPzBEJM68Bfw%2C1709698858%2C52336ee0b32be99689459910c85edbe5%2A32Cj7c04cc8aeb983d866b3b40c40aaf89e4IIEC', 'bili_jct': 'clfxqdnbxuc0530uctr5qgswh29hetqv', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'MHiQDjGFE5JCZaJ7OnDfFQ%2C1709698858%2Ce8771463dc3ece8532c0154ea17c57f5%2A32Cj79e6d92e13f35c530bd71ef6eff81c47IIEC', 'bili_jct': 'r6hxcvl0yuwai2sn6zb9xqv35i7o3teh', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'n1cazCuPFPKkFYKzjBasHw%2C1709698858%2C3a314f4552f2338dfd044af7373570c9%2A32Cjad7cceaf8d7b64b7e871e3161dbd1380IIEC', 'bili_jct': 'zrwam0uz81dei84s4l8x3f4o6d4vi93t', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'rLqd7z75TfE9kA+YPbnrig%2C1709698858%2Cdc4d67747d724d438597b88e87dfbb13%2A32Cj04342c5643745b0cec58b11fef12a744IIEC', 'bili_jct': 'qu48uf00ue9tid61xklrk11hehul4d2g', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': '2mPfewhEKTXrLb622O4Eyw%2C1709698858%2Cf70032a99b56ff9536166e8b8bcaf9ef%2A32Cj7654f99b57e3736431ad9700dfeda41aIIEC', 'bili_jct': '4mzktssm4z61jsu21zm51cicg65i8a27', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'oSx0qAf7OSUiQIyG3NMW0g%2C1709698858%2C4aa63a556a1fb7b40d5d66bce53080b1%2A32Cj14c338fa3ebf129727086e06a0c31a77IIEC', 'bili_jct': '32lby2qujadzomrid6vb1qv4tgdz8y3b', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'E1nRPRS48zelvs3OtdIEVQ%2C1709698858%2C34d4764d59a0540187d0372c8bf50d4c%2A32Cj5825bf0efa65aaf8065264c9ad11ca97IIEC', 'bili_jct': 'zhytymsex20mh06rri189kf1t5pjrhaz', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'QDCBjthtpDVRKxnpUBWsYA%2C1709698858%2C5a2336e61765773b751c8db485cef339%2A32Cj3ffa32303bf148226bc51963b9cc4ee1IIEC', 'bili_jct': '85off15h6799xwzswbmbjapcqp950sbi', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'a4gvbCaclclhXb6e/L1BTA%2C1709698858%2C64ef1c0ebadbf9a84d3a667b1509d3b4%2A32Cj0eddb9051ef7aff0543b5fd3702c1cb9IIEC', 'bili_jct': 'za2xlms5g08shxftpszp7kynjkh5drq8', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'khgkt1+WCzCDYv+N+wWbOw%2C1709698858%2C3db49d734b4354b2e74e757aec6ec3af%2A32Cj0066a97b4c9f1e49bd74c3ad63c589ceIIEC', 'bili_jct': 'kbuengqhdku7m387omoxa76gu5p4yjlz', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'Nj0DaM50zLoSocCgkc6YDg%2C1709698858%2C83d55d0bc462a6773b865ca4da11535d%2A32Cj50fb5d4483799e1b2fd0d4774ee56a8bIIEC', 'bili_jct': 'ynurug44v19rvb9vlo2eupky7c1r61lk', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'oBvzzREfmE70pUTlO7krYw%2C1709698858%2C0f4b4a6fb93320c58538b110e57191fc%2A32Cjff5a8814d7c9227d35d7c860d05563eeIIEC', 'bili_jct': 'wz8mxx5pqsas86pdpi6o9rtd4ngkjm2w', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': '6iunnAjAe/bl6wWnP87OSg%2C1709698858%2C9d14b8522d81cbc1ecee72210e79e9a7%2A32Cj66c48da75e5bdf2f2455481c75708b10IIEC', 'bili_jct': 'k15ltcs4zbha0iq6d5xljltsez0wkkl1', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'gk5hKX7osQzIQDFYWFw9Vw%2C1709698858%2Cb495dad362a71d90a85be8e74f82c953%2A32Cjed549b42c11fd57a9bd9631c5aac38cdIIEC', 'bili_jct': 'z6vzsljajlirh7dmui1bt3pg22g21dbw', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'uDt75GyMofLJCwgp2Xi29A%2C1709698858%2C4c02dcbecff8fbd6fda9210a6d3c7373%2A32Cjad73b5f9c5b1f1b06facd372a460beaeIIEC', 'bili_jct': '00bcrj9s9r5wwnaf7ac4ugylblm9yy7c', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'UpQ2pb3zXhtvhvSnnOUROQ%2C1709698858%2C51c12706a85445ed49374c0e1c763bf7%2A32Cj29eb0086f59f2116049f39e40c4059b2IIEC', 'bili_jct': 'jvuybkkh0cwmoxe87rhbfg27ccfcn15b', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': '6CHURwGrXu8Sc1jyecL4Og%2C1709698858%2C1eb339e6327048aba234ac184257b801%2A32Cj53db4b452555befe9ea15c8344ca9348IIEC', 'bili_jct': 'es6debsuzxbka7sleqkjwp7hvmoyvovr', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}
,
{'sessdata': 'bcKrIbJBg7RwQQ/oFnirYw%2C1709698858%2C922506d1e3041902a83b287e0d85e3e2%2A32Cjcf95479bcb084aa400c122365bc59d07IIEC', 'bili_jct': 't2dhk8gr7hlm4x7dlutdugk8m1ofvp9k', 'buvid3': '7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc'}

]

# 生成随机字节的辅助函数
def generate_random_bytes(length):
    return os.urandom(length)


# 生成sessdata的辅助函数
def generate_sessdata():
    # 模拟sessdata的生成过程，包括时间戳、随机字节和哈希值
    timestamp = str(int(time.time()))
    random_part = base64.b64encode(generate_random_bytes(16)).decode('utf-8').rstrip('=')
    hash_part = hashlib.md5((timestamp + random_part).encode('utf-8')).hexdigest()
    return f"{random_part}%2C{timestamp}%2C{hash_part}%2A32Cj{generate_random_bytes(16).hex()}IIEC"


# 生成bili_jct的辅助函数
def generate_bili_jct():
    # 生成一个固定长度的随机字符串作为bili_jct
    return ''.join(random.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=32))


# 生成并添加50条类似的数据到params列表中
# for _ in range(50):
#     new_data = {
#         "sessdata": generate_sessdata(),
#         "bili_jct": generate_bili_jct(),
#         "buvid3": "7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc"  # 假设buvid3是固定的
#     }
#     params.append(new_data)
#------------------------------------------------
def getParams():
    random_data = random.choice(params)

    return random_data

