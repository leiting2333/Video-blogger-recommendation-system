# -*- coding: utf-8 -*-
import requests
import json
import xlsxwriter as xw
import random
import time
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import jieba
from collections import Counter
import re
from snownlp import SnowNLP
import numpy as np

#哔哩哔哩BV号转AV号使用的变量
table = 'fZodR9XQDSUm21yCkr6zBqiveYah8bt4xsWpHnJE7jL5VG3guMTKNPAwcF'
tr = {}
for i in range(58):
    tr[table[i]] = i
s = [11, 10, 3, 8, 4, 6]
xor = 177451812
add = 8728348608

#代理IP
try:
    pro = [] #代理IP列表
    with open(r'../test/httpipcfg.txt', mode='r', encoding='utf-8') as f: #代理IP文档存放路径
        content = f.readline() # 按行读取
        print(content)
        while content: #循环最后一句的意义为当content读不到行时停止，这样能一行一行全部读取
            op = content.split() #用op对象存储，把一行切割成数组，去除空格
            pro.append(str(op[0]+":"+op[1])) #第一列数据下标为0
            content = f.readline()
    print('成功载入下列代理IP列表：')
    print(pro)
except:
    input('载入代理IP失败，请检查httpipcfg.txt是否正确存在脚本目录！')
#将文本中的非中文移除
def remove_non_chinese(text):
    pattern = re.compile('[^\u4e00-\u9fa5]')
    return pattern.sub('', text)
def dec(x): #BV转化为AV号
    if(x >= '0' and x <= '9'):#判断是否是纯数字，是的话就当做AV号，直接返回原本值
        return x
    else:
        r = 0
        for i in range(6):
            r = r+tr[x[s[i]]]*58**i
        return (r-add)^xor

#抓取评论
def gettext(url):
    headers1 = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36',
    }
    trytimes=0
    while trytimes<=50:
        httpip=random.choice(pro)
        response1 = requests.get(url,proxies={'http':str(httpip)},headers=headers1)#使用代理IP
        if(json.loads(response1.text)['code']==-412):
            trytimes = trytimes + 1
        else:
            trytimes=100
    if(trytimes>50 and trytimes!=100):
        input('抓取失败，访问频率过高！错误代码：-412，请稍后再试或更新代理IP！')
        exit(0)
    # response1 = requests.get(url,headers=headers1)#不使用代理IP
    response1.encoding = 'utf-8'
    response1.close()
    return response1.text

#写入表格中
def xw_toExcel(data, fileName):  # xlsxwriter库储存数据到excel
    workbook = xw.Workbook(fileName)  # 创建工作簿
    worksheet1 = workbook.add_worksheet("sheet1")  # 创建子表
    worksheet1.activate()  # 激活表
    title = ['用户名', 'UID','性别','个签', '头像','点赞数', '评论','情感指数','情感等级']  # 设置表头
    worksheet1.write_row('A1', title)  # 从A1单元格开始写入表头
    i = 2  # 从第二行开始写入数据
    for j in range(len(data)):
        insertData = [data[j]["用户名"], data[j]["UID"],data[j]["性别"],data[j]["个签"], data[j]["头像"], data[j]["点赞数"], data[j]["评论"],data[j]["情感指数"],data[j]['情感等级']]
        row = 'A' + str(i)
        worksheet1.write_row(row, insertData)
        i += 1
    workbook.close()  # 关闭表


try:
    BVID=input("请输入需要爬取评论的视频AV/BV号：")
    comment = json.loads(gettext("https://api.bilibili.com/x/v2/reply?pn=" + str(1) +  "&type=1&oid=" + str(dec(BVID)) + "&sort=2"))
except:
    input('抓取错误，请检查输入的AV/BV号！')
    exit(0)
if comment['code']==-412:
    input('抓取失败，访问频率过高！错误代码：-412，请稍后再试！')
    exit(0)
elif comment['code']!=0:
    input('抓取失败，错误代码：'+str(comment['code']))
    exit(0)
#抓取前的变量设置
pagenum=1#当前页
commentnum=0#总评论数量（不计算楼中楼评论）
commentlist=[] #存抓取信息的变量
commentLength = len(comment)#当前页评论数量
commenttext="" #一个用来存取所有评论的变量
male=0
female=0
nomale=0
feeling=0.0
femalefeel=0.0
malefeel=0.0
nomalefeel=0.0

#开始抓取评论，直到下一页没有评论
while commentLength!=0:
    time.sleep(0.1)
    comment = json.loads(gettext("https://api.bilibili.com/x/v2/reply?pn=" + str(pagenum) + "&type=1&oid=" + str(dec(BVID)) + "&sort=2"))
    comment = comment['data']['replies']#数据清洗，只留下抓取信息中的评论信息
    try:
        commentLength = len(comment)
    except:
        break
    for index in range(commentLength):
        username=str(comment[index]['member']['uname'])
        uid=str(comment[index]['member']['mid'])
        usex=str(comment[index]['member']['sex'])
        usigh=str(comment[index]['member']['sign'])
        uhead=str(comment[index]['member']['avatar'])
        ucom=str(comment[index]['content']['message'])
        ulike=str(comment[index]['like'])
        print('用户名：'+username)  # 用户名
        print('UID：'+uid)  # UID
        print('性别：'+usex)  # 性别
        print('个签：'+usigh)  # 性别
        print('头像：'+uhead)  # 用户头像
        print('评论：'+ucom)  # 评论内容
        sss = SnowNLP(ucom)#情感分析
        sentiment = sss.sentiments#情感指数（越接近1越积极）
        feeling=feeling+sentiment
        if usex=='男':
            male=male+1
            malefeel=malefeel+sentiment
        elif usex=='女':
            female=female+1
            femalefeel=femalefeel+sentiment
        else:
            nomale=nomale+1
            nomalefeel=nomalefeel+sentiment
        commenttext=commenttext+ucom  # 存入评论内容备用
        print('点赞数：'+ulike)  # 点赞
        #判断评论负面等级，越大证明评论越积极，但仅仅通过文本，结果仅供参考，要依据实际情况判断
        if(sentiment>0.6):
            ufeel='积极'
        elif(sentiment<0.4):
            ufeel='消极'
        else:
            ufeel='中性'
        print('情感等级：'+ufeel+'\n')
        commentdic={}
        commentdic.update({'用户名':username,'UID':uid,'性别':usex,'个签':str(comment[index]['member']['sign']),
                           '头像':uhead,'点赞数':ulike,'评论':ucom,'情感指数':sentiment,'情感等级':ufeel})
        commentlist.append(commentdic)
    pagenum=pagenum+1
    commentnum=commentnum+commentLength

feeling=float(feeling/commentnum)*100
if male!=0:
    malefeel=float(malefeel/male)*100
if nomale!=0:
    nomalefeel=float(nomalefeel/nomale)*100
if female!=0:
    femalefeel=float(femalefeel/female)*100
#移除评论中的非中文字符并且分割评论，并统计词频
commenttext=remove_non_chinese(commenttext)
words = jieba.cut(commenttext)
word_counts = Counter(words)
sorted_word_counts = sorted(word_counts.items(), key=lambda x: x[1], reverse=True)

#制作词频词云
wordcloud = WordCloud(
    font_path="msyh.ttc",  # 在这里添加
    background_color='white',
    width=1000,
    height=1000,
    max_words=300,
    max_font_size=200,
    min_font_size=20,
    prefer_horizontal=0.95).generate_from_frequencies(dict(sorted_word_counts))
wordcloud.to_file(BVID+'词云.jpg')


sexfcount=[malefeel, femalefeel, nomalefeel, feeling]
sexname=['男性', '女性', '保密', '全部']
sexindex=np.arange(len(sexname))
# 正确显示中文和负号
plt.rcParams["font.sans-serif"] = ["SimHei"]
plt.rcParams["axes.unicode_minus"] = False
p1=plt.bar(sexindex, sexfcount)
plt.bar_label(p1, label_type='edge')
# plt.subplot(121)
plt.title(BVID+'性别情感指数柱状图')
plt.xlabel('性别')
plt.ylabel('情感指数')
plt.xticks(sexindex, sexname)
plt.savefig(BVID+'性别情感指数图.png')
plt.show()

plt.figure()

sexcount=[male, female, nomale]
labels = ['男性', '女性', '保密']
plt.title(BVID+'性别比例（共'+str(commentnum)+'）人')
plt.pie(sexcount, autopct='%1.1f%%', labels=labels)
plt.savefig(BVID+'性别比例图.png')
plt.show()
plt.figure()
print('共计['+str(commentnum)+']条评论')
fileName=BVID+'视频评论.xlsx'
xw_toExcel(commentlist, fileName)
input('完成！')


