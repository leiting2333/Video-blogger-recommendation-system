from datetime import datetime
from bilibili_api import Credential, sync, settings
from message import GetMessage
import pymysql
from dbutils.pooled_db import PooledDB
import json
import time
import random
import sys
import requests
from tools.tools import getWtsAndW_rid
from random_headers import getHeaders
import asyncio


# getFansData方法区域
def getFansData(uid: int):
    data_list = []
    headers = getHeaders()
    data_list = getWtsAndW_rid(headers)
    wts = data_list[0]
    w_rid = data_list[1]
    # url1=f"https://api.bilibili.com/x/space/wbi/acc/info?mid={uid}&token=&platform=web&web_location=1550101&{result}&wts={wts}&w_rid={w_rid}"
    url2 = f"https://api.bilibili.com/x/relation/stat?vmid={uid}&web_location=333.999&w_rid={w_rid}&wts={wts}"
    url3 = f"https://api.bilibili.com/x/space/upstat?mid={uid}&web_location=333.999"
    res1 = requests.get(url2, headers=headers).json()

    # res2=requests.get(url3,headers=headers).json()
    following = res1["data"]["following"]
    follower = res1["data"]["follower"]
    # view=res2["data"]["archive"]["view"]
    # likes=res2["data"]["likes"]
    data_list.append(following)
    data_list.append(follower)
    # data_list.append(likes)
    # data_list.append(view)

    print(data_list)
    return data_list


# getFansData区域结束
params = {
    "sessdata": "582b57de%2C1727323299%2Ccd5f9%2A32CjB1f1Ekhzdtkc_mihoJQost1TZiaHBfNI_Ixq0jvLaS3yPYnZPbtYZw5TPku2ercqoSVlFsTVE5eTBnNG9OQjYxODI5Qlo5ZUF4VmxjUFV6NHQwTmkxaHQ3a1VDSm90ZjR2Z2lkNGFkZjJUS0NUcGNLV0JuTGRndk9mbGhBZ3J4MlhJSnEyTWh3IIEC",
    "bili_jct": "31b469daf8014b6bc9cd98074dc3fc13",
    "buvid3": "7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc",
    "buvid4": "9102DB61-C936-F771-E817-E04937ACAD6070805-023123109-WudIogupiG7%2Bkd9mLv%2B9AQ%3D%3D",
    "dedeuserid": "227583061",
}
pool = PooledDB(
    creator=pymysql,  # 使用 pymysql 作为数据库连接库
    maxconnections=10,  # 连接池大小为 10
    host='localhost',
    port=3306,
    user='root',
    password='123456',
    database='bilibili',
    charset='utf8mb4'
)


def re(uid: int):
    credential = Credential(sessdata=params["sessdata"], bili_jct=params["bili_jct"],
                            buvid3=params["buvid3"], dedeuserid=params["dedeuserid"])  # 生成一个 Credential 对象
    message = GetMessage(uid, credential)
    return message


# 将获取的数据插入数据库中,并且更新之前博主表中分区信息
async def insertAndUpdate(data_to_insert: list, top_three_data, uid, sql_list: list):
    conn = pool.connection()  # 获取链接
    cursor = conn.cursor()
    try:
        print(f"----{uid}--执行该用户的插入操作!")
        cursor.execute(sql_list[0])
        print(f"----{uid}--该用户的基本信息在插入成功!")
    except Exception as e:
        print(f"----{uid}--该用户的基本信息已存在插入失败")
    try:
        cursor.execute(sql_list[1])
        print(f"----{uid}--该用户的基本信息更新成功")
    except Exception as e:
        print(f"----{uid}--该用户的基本信息更新失败")

    for i in range(len(data_to_insert)):
        try:
            # 插入数据
            cursor.execute(
                "INSERT INTO videos (comment, play, pic, description, title, author, mid, created, length, video_review, aid, bvid) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                (data_to_insert[i]['comment'], data_to_insert[i]['play'], data_to_insert[i]['pic'],
                 data_to_insert[i]['description'], data_to_insert[i]['title'], data_to_insert[i]['author'],
                 data_to_insert[i]['mid'], data_to_insert[i]['created'], data_to_insert[i]['length'],
                 data_to_insert[i]['video_review'], data_to_insert[i]['aid'], data_to_insert[i]['bvid']))
        except Exception as e:

            print("插入语句的数据重复啦,没关系:", e)

    # 修改表字段内容的SQL语句
    update_query = """
                   UPDATE up_info_bak
                   SET tid = ?
                   WHERE uid = ?; 
                   """

    data_string = json.dumps(top_three_data, ensure_ascii=False)
    query = "UPDATE up_info_bak SET tid = '{}' WHERE uid = '{}'".format(data_string, uid)
    print(data_string)
    # 修改字段
    try:
        cursor.execute(query)

        print("更新语句成功了:", uid)

    except Exception as e:
        print("更新出错:", e)
    # 提交更改并关闭连接
    conn.commit()
    conn.close()


def updataTid():
    conn = pool.connection()  # 获取链接
    cursor = conn.cursor()

    conn.commit()
    # 提交更改并关闭连接
    conn.close()


async def writerDaiBiaoVideo(list_video, uid):
    conn = pool.connection()  # 获取链接
    cursor = conn.cursor()
    if list_video != "暂无代表作" and list_video is not None and len(list_video) > 0:
        try:
            for i in range(len(list_video)):
                cursor.execute(list_video[i])  # 执行
            print("写入成功!!!!!!!!!!!!!!!!!")
            # getDataInfo(423895)
        except Exception as e:
            print(uid + ":没有成功写入代表作" + e)
        conn.commit()
    else:
        print(f"========={uid}-没有代表作")

    # 提交更改并关闭连接
    conn.close()


async def statUpFansToChart(data_to_insert: list, uid):
    conn = pool.connection()  # 获取链接
    cursor = conn.cursor()

    # 查询数据库副表中的该uid的信息是否存在,如果存在我们就读取他的following数据
    # 定义查询语句模板
    query_template = "SELECT * FROM up_stat_chart_back WHERE `uid` =%s"
    # 使用参数化查询执行查询

    try:
        cursor.execute(query_template, (uid,))
        results = cursor.fetchall()
    except Exception as e:
        print(f"-------{uid}:的数据在数据库中不存在+---")

    data_insert = []
    # 获取查询结果
    print(results)
    # 判断结果的up_following是否为空
    if (len(results) >= 1):
        for row in results:
            if (row[1] is not None and row[1] != ''):
                print("运行到了不为空")
                data_insert = json.loads(row[1])
                if (data_insert[-1]["date"] != data_to_insert[-1]["date"]):
                    data_insert.append(data_to_insert[-1])
                    print("日期不重复,加入成功")
                if (data_insert[-1]["date"] == data_to_insert[-1]["date"]):  # 如果日期一样就更新数据
                    data_insert[-1]["following"] = data_to_insert[-1]["following"]
                    data_insert[-1]["view"] = data_to_insert[-1]["view"]
                    data_insert[-1]["likes"] = data_to_insert[-1]["likes"]
                    print("日期重复,更新成功")

    else:
        print("运行到了为空的状况")
        data_insert = data_to_insert
    print(data_insert)
    # 将传进来的列表转成字符串
    data_string = json.dumps(data_insert, ensure_ascii=False)
    # 用来写入副表中的数据,以列表字符串的形式
    query_one = "UPDATE up_stat_chart_back SET up_following = '{}' WHERE uid = '{}'".format(data_string, uid)

    # 准备插入语句
    insert_statement = '''
    INSERT INTO up_stat_chart (uid,up_following, up_view, likes,date)
    VALUES (%s,%s, %s,%s,%s)
    '''
    insert_statementSecond = '''
    INSERT INTO up_stat_chart_back (uid,up_following)
    VALUES (%s,%s)
    '''
    # 获得传进来的数据的最后一组数,因为最后一组数才是我们最新获取的数据,用来写入原表
    last_data = data_insert[-1]
    data_one = (uid, last_data["following"], last_data["view"], last_data["likes"], last_data["date"])
    data_two = (uid, data_string)

    # 插入原表的执行语句
    try:
        cursor.execute(insert_statement, data_one)
        print("原表插入成功了?")
    except Exception as e:
        conn.rollback()  # 回滚事务
        print(f"-------这组数据应该已经存在了{uid}+---{last_data["date"]}")
    # 插入副表的执行语句
    try:
        cursor.execute(insert_statementSecond, data_two)
    except Exception as e:
        cursor.execute(query_one)
        print(f"-------这组数据应该已经存在了,副表--{uid}---已经进行修改操作--")

    conn.commit()
    # 提交更改并关闭连接
    conn.close()
    # 要插入的数据


# 读取数据库中的up_info_bak中的uid写入文件
def writerTest():
    conn = pool.connection()  # 获取链接
    cursor = conn.cursor()

    # 查询数据库表中的 uid 字段
    query = "SELECT uid FROM up_info_bak"
    cursor.execute(query)
    # 获取查询结果
    results = cursor.fetchall()

    # 将 uid 写入文件
    with open('../file_using/uids.txt', 'w') as f:
        for row in results:
            f.write(str(row[0]) + '\n')
    # 关闭连接
    conn.close()


def getVideos(parm):
    # uidList=getUidList()

    # for i in range(1639,len(uidList)):
    #    uid=uidList[i]
    uid = parm
    # print(f"==========当前加载到第{i}个博主,uid为:{uid}============")
    message = re(uid)
    # 获取用户基本信息的插入和更新语句
    sql_list = message.get_user_info1()
    # 这个1表示只找第一页的的数据
    try:
        msg: dict = message.get_videos(1)
    except Exception as e:
        print(f"-------这个人好像没{uid}")
    list = msg["list"]
    # 将数据以json格式写入文件,便于观察理解
    # json_writer_dict("../file_using/test.json", msg)
    # 排序并取前三
    sorted_list = sorted(list["tlist"].values(), key=lambda x: x["count"], reverse=True)[:3]
    # 提取名称和对应的 count 值,可以直接将该值
    top_three_data = [{"name": item["name"], "count": item["count"]} for item in sorted_list]
    # 将总 count 包含在最后一个元素中
    top_three_data.append({"name": "总count", "count": msg["page"]["count"]})
    # 打印结果
    print("排行前三的数据及总 count：")
    for item in top_three_data:
        print(item)

    # 前30个视频按 播放量play 大小排序
    sorted_vlist = sorted(list["vlist"], key=lambda x: x["play"], reverse=True)
    # 取出前三的数据
    top_three_vlist = sorted_vlist[:3]
    # 打印结果
    # print("前三个数据按照 play 大小排序：")
    # for item in top_three_vlist:
    #     print(item)
    # 调用方法将我们的数据插入数据库和更新咱们的表中tid字段
    sync(insertAndUpdate(top_three_vlist, top_three_data, uid, sql_list))  # 有可能有误
    # 生成1到3之间的随机浮点数
    # 获得up的代表作
    list = message.get_masterpiece()  # 很费时间
    # 调用方法把up的代表作写入数据库
    if len(list) > 0:
        sync(writerDaiBiaoVideo(list, uid))


def getUpAllStat():
    # uidList=getUidList()
    # print(uidList)
    # for i in range(971,len(uidList)):
    #     print(f"当前运行到第--------{i}-行")
    uid = 16419172
    message = re(uid)
    now = datetime.now()
    just_date = now.strftime("%Y-%m-%d")
    msg = getFansData(uid)
    sleep_duration = random.uniform(0.5, 2)
    # # 休眠随机时长
    time.sleep(sleep_duration)
    msgTwo: dict = message.get_up_stat()
    while msgTwo == 1:  # 如果调用请求失败就在请求一次
        msgTwo: dict = message.get_up_stat()
    data_list = []
    data_list.append(
        {"date": just_date, "following": msg[3], "view": msgTwo["archive"]["view"], "likes": msgTwo["likes"]})
    print(data_list)
    statUpFansToChart(data_list, uid)
    # 生成1到3之间的随机浮点数
    sleep_duration = random.uniform(0.5, 2)
    # # 休眠随机时长
    # time.sleep(sleep_duration)


def updateUpStat(parm):
    print(f"当前添加博主uid为--------{parm}-行")

    uid = parm
    message = re(uid)
    now = datetime.now()
    just_date = now.strftime("%Y-%m-%d")
    msg = getFansData(uid)
    if (msg[3] < 100000):
        return 0  # 当添加的博主粉丝数小于十万代表这个博主不符合
    time.sleep(1)
    getVideos(uid)
    # 调用方法获取用户的基本信息和将数据添加到数据库中

    # # 休眠随机时长
    time.sleep(2)
    msgTwo: dict = message.get_up_stat()
    while msgTwo == 1:  # 如果调用请求失败就在请求一次
        msgTwo: dict = message.get_up_stat()
    data_list = []

    data_list.append(
        {"date": just_date, "following": msg[3], "view": msgTwo["archive"]["view"], "likes": msgTwo["likes"]})
    print(data_list)
    sync(statUpFansToChart(data_list, uid))  # 将获取的数据拿去添加数据库中
    # 生成1到3之间的随机浮点数
    return 1
    sleep_duration = random.uniform(0.5, 2)
    # # 休眠随机时长
    time.sleep(sleep_duration)

#添加和更新博主信息的脚本,核心脚本之一
if __name__ == '__main__':
    stateStr = sys.argv[1];
    number=updateUpStat(stateStr);
    print(number);
