import random
import time

from bilibili_api import Credential, sync
from message import GetMessage
from random_cookie import getParams
from dbutils.pooled_db import PooledDB
import pymysql

pool = PooledDB(
    creator=pymysql,  # 使用 pymysql 作为数据库连接库
    maxconnections=10,  # 连接池大小为 10
    host='localhost',
    port=3306,
    user='root',
    password='123456',
    database='bilibili',
    charset='utf8mb4'
)
params = {
    "sessdata": "e1d31719%2C1725038688%2C4b378%2A32CjB7UYFhUpbXtX_zRW2ifJwC2UwKiMK2-2VQi9N8pduvbuQiTPgb_mon2voTAEWPVzsSVjJzeEM4eExvYUdtLTdWODVtTy1CeVBROGtEVWxQNkk3OXBkOUNjUFpfRHBpcVZJRS1iUTFwd045Q1FIZVNrOHFVVXlkcmwzWmZVNG5HZ2RqQ1ktSFVRIIEC",
    "bili_jct": "100c4689af4dd02381b10cbd725c3a8e",
    "buvid3": "7DAA7DC3-63F9-A34F-32E8-D086D86C74AA75649infoc"
}




def reObj(uid: int):
    credential = Credential(sessdata=params["sessdata"], bili_jct=params["bili_jct"],
                            buvid3=params["buvid3"])  # 生成一个 Credential 对象
    message = GetMessage(uid, credential)
    return message


def getUserInfo(uid: int):  # 获取用户基本信息
    clas=reObj(uid)
    list=clas.get_masterpiece()
    time.sleep(random.randint(1,2))
    sql=clas.get_user_info1()  # 调用隔壁的获取用户信息方法

    relist=[sql,list]
    return relist


"""def getTopVideo(uid: int):  # 获取代表作信息
    list = reObj(uid).get_masterpiece()
    return list"""


def getDataInfo(uid: int):
    # reObj(uid).get_up_stat()

    reObj(uid).get_relation_info()

def get_uid_list():
    # 代理IP
    try:
        pro = []  # 代理IP列表
        with open(r'../file_using/uid_collet.txt', mode='r', encoding='utf-8') as f:  # 代理IP文档存放路径
            content = f.readline()  # 按行读取
            i = 1
            while content is not None:  # 循环最后一句的意义为当content读不到行时停止，这样能一行一行全部读取

                i += 1
                op = int(content)  # 用op对象存储，把一行切割成数组，去除空格
                pro.append(op)  # 第一列数据下标为0
                #print(op)
                content = f.readline()
    except Exception as e:
        print(e)
    print('成功载入下列代理IP列表：')
    print(pro)
    return pro


if __name__ == '__main__':


    list= get_uid_list()
    conn = pool.connection()  # 获取链接
    cursor = conn.cursor()
    start=1671
    for i in range(start,len(list)):
        uid = int(list[i])
        relist=getUserInfo(uid)
        list_video = relist[1]
        list_up_info = relist[0]
        if list_video != "暂无代表作" and list_video is not None:
            try:
                for i in range(len(list_video)):
                    cursor.execute(list_video[i])  # 执行

                print("写入成功!!!!!!!!!!!!!!!!!")
                    # getDataInfo(423895)
            except Exception as e:
                print(e)


            finally:
                print(f"==============当前在第:{start}----uid:{uid}")
                start = start+1
                time.sleep(1)
        else:
            print(f"========={uid}-没有代表作")
        cursor.execute(list_up_info)
        conn.commit()
        print(uid)
    # 关闭连接
    cursor.close()
    conn.close()
