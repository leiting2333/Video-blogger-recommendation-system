from math import floor
from random import random
import random

def f114i(a, b, i):
    t = floor(random() * (114 * i))
    return [3 * a + 2 * b + t, 4 * a - 5 * b + t, t]

def f114(a, b):
    t = floor(random() * 114)
    return [2 * a + 2 * b + 3 * t, 4 * a - b + t, t]

def f514(a, b):
    t = floor(random() * 514)
    return [3 * a + 2 * b + t, 4 * a - 4 * b + 2 * t, t]

eventTypes = ["mousemove", "click"]

def getDmImgList(events):
    result = []
    for index, event in enumerate(events):
        x, y, z = f114i(event.x, event.y, index)
        timestamp = floor(event.timeStamp)
        k = floor(random() * 67) + 60
        type_ = eventTypes.index(event.type)
        result.append({"x": x, "y": y, "z": z, "timestamp": timestamp, "k": k, "type": type_})
    return result

tagNames = [
    "span", "div", "p", "a", "img", "input", "button", "ul", "ol", "li",
    "h1", "h2", "h3", "h4", "h5", "h6", "form", "textarea", "select", "option",
    "table", "tr", "td", "th", "label", "strong", "em", "section", "article"
]

def getDmImgInter(windowBounds, elements):
    ds = []
    for element in elements:
        bounds = element.getBoundingClientRect()
        x1, y1, z1 = f114(bounds.y | 0, bounds.x | 0)
        x2, y2, z2 = f514(bounds.width | 0, bounds.height | 0)
        ds.append({
            "t": tagNames.index(element.tagName.lower()) + 1,
            "c": element.className[:-2].encode("ascii").decode("base64"),
            "p": [x1, z1, y1],
            "s": [z2, x2, y2]
        })
    wh = f114(windowBounds.width, windowBounds.height)
    of = f514(windowBounds.y, windowBounds.x)
    return {"ds": ds, "wh": wh, "of": of}

# def randomSample(population, sampleSize):
#     if sampleSize > len(population):
#         raise ValueError('Sample size exceeds population size')
#
#     shuffled = population[:]
#     i = len(population)
#     while i:
#         i -= 1
#         index = floor((i + 1) * random())
#         shuffled[i], shuffled[index] = shuffled[index], shuffled[i]
#
#     return shuffled[:sampleSize]

def randomSample(population, sampleSize):
    if sampleSize > len(population):
        raise ValueError("Sample size exceeds population size")

        # 创建 population 的一个浅拷贝来避免修改原始列表
    shuffled = population[:]

    # Fisher-Yates 洗牌算法
    for i in range(len(shuffled) - 1, 0, -1):
        # 生成一个介于 0 和 i 之间的随机整数
        j = random.randint(0, i)
        # 交换 shuffled[i] 和 shuffled[j]
        shuffled[i], shuffled[j] = shuffled[j], shuffled[i]

        # 返回前 sample_size 个元素作为样本
    return shuffled[:sampleSize]


def getDm():
    dm_rand = 'ABCDEFGHIJK'
    dm_img_list = '[]'
    dm_img_str = ''.join(randomSample(list(dm_rand), 2))
    dm_cover_img_str = ''.join(randomSample(list(dm_rand), 2))
    dm_img_inter = "%7B%22ds%22:[],%22wh%22:[0,0,0],%22of%22:[0,0,0]%7D"
    return '&'.join([f'{key}={value}' for key, value in {
        'dm_img_list': dm_img_list,
        'dm_img_str': dm_img_str,
       'dm_cover_img_str': dm_cover_img_str,
        'dm_img_inter': dm_img_inter
    }.items()])


if __name__ == '__main__':
    # 调用 getDm 方法
    result = getDm()
    # 输出结果
    print(result)


