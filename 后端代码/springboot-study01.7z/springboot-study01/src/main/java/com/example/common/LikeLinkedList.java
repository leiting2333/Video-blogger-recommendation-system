package com.example.common;
import com.example.exception.CustomException;
import com.example.pojo.UpInfoSecond;
import com.example.pojo.UserInfo;
import com.example.service.UserInfoServiceImp;
import com.example.service.inter.UserInfoService;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

@Component
public class LikeLinkedList {

    private static final int MAX_SIZE = 20;
    private static final LinkedList<UpInfoSecond> list = new LinkedList<>();//喜欢列表中的博主数据
    @Getter
    private static final LinkedList<String> addList = new LinkedList<>();

    //获取唯一可用的对象
    //创建 SingleObject 的一个对象
    @Getter
    private static final LikeLinkedList instance = new LikeLinkedList();


    public void addObject(UpInfoSecond obj) {
        list.addFirst(obj); // 在链表最前面插入新对象
        while (list.size() > MAX_SIZE) {
            list.removeLast(); // 如果超过最大大小，删除最后一个对象
        }
    }

    public void addString(String uid) {
        addList.addFirst(uid); // 在链表最前面插入新对象
        System.out.println(addList.size() );
        while (addList.size() > MAX_SIZE) {
            addList.removeLast(); // 如果超过最大大小，删除最后一个对象
            System.out.println("发生什么事了"+addList.size() );
        }
    }

    //将uid加入数组并写入数据库中
    public UserInfo addLikeList(String uid,UserInfo userInfo1) {
        //从数据库中找到该用户的信息
        String likeList="";

        if (userInfo1==null){
            throw new CustomException("点赞失败!!");
        }

        String likeList1 = userInfo1.getLike_list();//获得该博主的喜欢列表

        if (likeList1!=null && !likeList1.equals("")){//此处必须写成equals,不然会出问题.
            //将读取的喜欢列赋值给likeList
            likeList=userInfo1.getLike_list();

            if (addList.isEmpty()){
                for (String s : UserInfoServiceImp.convertToArray(likeList)) {//将字符串的uid数组转成字符串数组
                    System.out.println(s);
                    addString(s);
                }

            }
            addString(uid);
            likeList = Arrays.toString(addList.toArray(new String[0]));


        }else {
            addString(uid);
            likeList = Arrays.toString(addList.toArray(new String[0]));
        }
        userInfo1.setLike_list(likeList);
        //把信息更新回去

        return userInfo1;

    }




}

