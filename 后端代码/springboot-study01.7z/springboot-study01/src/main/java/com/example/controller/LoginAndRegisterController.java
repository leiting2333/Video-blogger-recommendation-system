package com.example.controller;

import com.example.common.JwtTokenUtils;
import com.example.common.Result;
import com.example.dao.emailService;
import com.example.pojo.Login;
import com.example.pojo.ManageInfo;
import com.example.pojo.UserInfo;
import com.example.service.inter.ManageInfoService;
import com.example.service.inter.UserInfoService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Objects;

@CrossOrigin
@RestController
public class LoginAndRegisterController {
    public static String tokenPub="";
    @Resource(name = "manageInfoServiceImp")
    ManageInfoService manageInfoService;
    @Resource(name = "userInfoServiceImp")
    UserInfoService userInfoService;

    public static boolean isChinesePhoneNumber(String phoneNumber) {
        // 中国大陆手机号码正则表达式
        // 1[34578]\d{9} 表示以1开头，第二位为3、4、5、7、8中的一个，后面跟9个任意数字
        String regex = "^1[34578]\\d{9}$";
        return phoneNumber != null && phoneNumber.matches(regex);
    }

    //用户登录判定
    @RequestMapping("/userLogin")
    public Result userLogin(@RequestBody Login login,HttpServletRequest request) {
        System.out.println("登录验证");
        if (login.getPassword() == null || login.getEmail() == null) {
            return Result.Error("信息不能为空!");
        }
        //如果是手机号则判断是管理员登录
        if (isChinesePhoneNumber(login.getEmail())) {
            System.out.println("管理登录验证");
            //查询管理员表,判断是否账号存在
            List<ManageInfo> manageInfos = manageInfoService.queryManageInfoByNumberLimit(login);
            //如果不存在则提示
            if (manageInfos.isEmpty()) {
                return Result.Error("账号或密码错误");
            }
            //如果账号存在,则判断密码是否正确
            if (Objects.equals(manageInfos.get(0).getPassword(), login.getPassword())) {
                System.out.println("管理登录验证成功!!");
                //获得管理员对应的token
                ManageInfo manageInfo = manageInfos.get(0);
                String token = JwtTokenUtils.genToken(Long.toString(manageInfo.getNumber()), manageInfo.getPassword());
                manageInfo.setToken(token);
                tokenPub=token;
                //创建session

                HttpSession session=request.getSession();//这就是session的创建
                System.out.println(session.getId());

                //将带有token的数据返回
                return Result.success(manageInfo);
            } else {
                return Result.Error("账号或者密码错误!");
            }
            //如果不是管理员登录,则认为是用户登录
        } else {
            System.out.println("用户登录验证");
            List<UserInfo> userInfos = userInfoService.queryUpInfoByEmail(login);
            if (userInfos.isEmpty()) {
                System.out.println("用户登录验证失败1");
                return Result.Error("账号未注册!");
            }
            System.out.println(userInfos.get(0).getPassword());
            if (Objects.equals(userInfos.get(0).getPassword(), login.getPassword())) {
                UserInfo userInfo=userInfos.get(0);
                String token = JwtTokenUtils.genToken(userInfo.getEmail(), userInfo.getPassword());
                tokenPub=token;
                userInfo.setToken(token);
                System.out.println("用户登录验证成功");
                //创建session
                HttpSession session=request.getSession();//这就是session的创建
                System.out.println(session.getId());
                session.setMaxInactiveInterval(30*60);//以秒为单位，即在没有活动30分钟后，session将失效

                return Result.success(userInfo);

            } else {
                System.out.println("用户登录验证失败2");
                return Result.Error("账号或者密码错误!");
            }

        }

    }

    @Resource
    private emailService emailService;

    @GetMapping("/getCode")
    public String sendCode(String to, HttpSession httpSession) {
        String randomCode = emailService.email(to);
        httpSession.setAttribute("code", randomCode);
        return "验证码已发送到指定邮箱" + randomCode;
    }

    @GetMapping("/checkCode")
    public String checkCode(String code, HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) {
            return "验证码未发送";
        }
        String Code = (String) session.getAttribute("code");
        if (code.equals(Code)) {
            return "验证码正确";
        }
        return "验证码错误";
    }

    //用户注册判定
    @RequestMapping("/userRegister")
    public Result userRegister(@RequestBody Login login) {
        System.out.println("注册判断");
        if (!login.judgeAttr()) {
            return Result.Error("不能为空");
        }
        if (!Objects.equals(login.getPassword(), login.getPassword2())) {
            return Result.Error("两次输入密码不一致");
        }

        List<UserInfo> userInfos = userInfoService.queryUpInfoByEmail(login);
        if (!userInfos.isEmpty()) {
            return Result.Error("用户已存在");
        }
        userInfoService.addUserInfo(login);
        return Result.success();

    }


}
