package com.example.controller;

import com.example.common.JwtInterceptor;

import com.example.common.JwtTokenUtils;
import com.example.common.Result;
import com.example.pojo.*;
import com.example.service.inter.UserInfoService;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;

@CrossOrigin
@RestController
public class UserInfoController {
    @Resource(name="userInfoServiceImp")
    UserInfoService userInfoService;

    @RequestMapping("/userInfo")
    public Result getUserInfo(Params params){
        return Result.success(userInfoService.queryUpInfoList(params)) ;
    }

    @RequestMapping("/userInfo/searchByName")
    public Result getUserInfoByName(Params params){
        if (params.getInput1()==null){
            return Result.Error("没查询到用户");
        }
        return Result.success(userInfoService.queryUpInfoByName(params)) ;
    }

    @RequestMapping("/userInfo/searchByEmail")
    public Result getUserInfoByEmail(Params params){
        if (params.getInput1()==null){
            return Result.Error("没查询到用户");
        }
        return Result.success(userInfoService.queryUpInfoByEmail(params)) ;
    }
    @RequestMapping("/userInfo/addUserInfo")
    public Result addUserInfo(@RequestBody UserInfo userInfo){

        if ( userInfo.getId() == null) {
            //添加判断
           userInfoService.addUserInfo(userInfo);
            return Result.success() ;
        } else {
           //编辑判断
            userInfoService.updateUserInfo(userInfo);
            return Result.success();
        }

    }
    @RequestMapping("/userInfo/delUserInfo")
    public Result delUserInfo(@RequestBody UserInfo userInfo){


        if ( userInfo.getId() != null) {
            return Result.success(userInfoService.delUserInfoById(userInfo)) ;
        } else {
            return Result.Error("不存在");
        }

    }

    @RequestMapping("/userInfo/Preference")
    public Result userPreference(@RequestBody UserInfo userInfo){
        System.out.println(userInfo);
        /*
        判断用户传递来到内容是否为空
        上一步不为空以后,获得传信息的用户email,根据email从数据库中查找到这个用户的信息
        如果信息不为空,则读取用户的like,如果like为空则把我们传递来到like和信息写进去
         */
        if(userInfo.getSex()==null || userInfo.getAge()<=1 || userInfo.getCareer()<0){
            return Result.Error("不能为空!");
        }
        if(userInfo.getAge()>120 ){
            return Result.Error("年龄不符!");
        }
        userInfoService.updateUserInfoByEmail(userInfo);
        UserInfo userInfo1 = userInfoService.queryUpInfoByEmail(JwtInterceptor.email);
        String token = JwtTokenUtils.genToken(userInfo1.getEmail(), userInfo1.getPassword());
        userInfo1.setToken(token);
        return Result.success(userInfo1);

    }

    @RequestMapping("/userInfo/popup")
    public Result userPopup(){
        /*
       判断用户的like是否为空,如果为空则返回ture
         */
        UserInfo userInfo = userInfoService.queryUpInfoByEmail(JwtInterceptor.email);
        if (userInfo.getLike()==null || userInfo.getLike().equals("")){//这个地方要用equals
            return Result.Error("用户like为空");
        }
        return Result.success("提交成功");

    }


    @RequestMapping("/userInfo/returnLikeList")
    public Result returnLikeList() throws JsonProcessingException {

        List<UpInfoSecond> upInfoSeconds = userInfoService.queryUpInfoSecondByUid();
        if (upInfoSeconds==null || upInfoSeconds.isEmpty()){
            return Result.Error("列表加载失败!");
        }
        return Result.success(upInfoSeconds);

    }

    @RequestMapping( "/userInfo/addLikeList")
    public Result addLikeLists(@RequestBody Uid uid){
        /*
       当用户产生点赞行为时出发,改变用户数据库中的喜欢列表内容
       获取被点赞的博主的uid
         */
        System.out.println(uid);
        if (uid==null){
            return Result.Error("uid传递失败");
        }
        userInfoService.addLikeList(String.valueOf(uid.getUid()));
        UserInfo userInfo = userInfoService.queryUpInfoByEmail(JwtInterceptor.email);
        String token = JwtTokenUtils.genToken(userInfo.getEmail(), userInfo.getPassword());
        userInfo.setToken(token);
        return Result.success(userInfo);

    }

    @GetMapping( "/userInfo/addNewUp/{uid}")
    public Result addNewUp(@PathVariable long uid){
        /*
       当用户产生点赞行为时出发,改变用户数据库中的喜欢列表内容
       获取被点赞的博主的uid
         */



        if (uid<1 ){
            return Result.Error("uid不符");
        }else {

            try {
                System.out.println(uid);
                // 构建Python脚本命令
                String command = "python D:\\project\\PyProject\\hello\\project01\\bilibili\\add_and_update_up_msg.py " + uid;
                //D:\project\PyProject\hello\project01\bilibili_user_message\Test.py
                // 执行Python脚本
                Process process = Runtime.getRuntime().exec(command);
                // 读取Python脚本输出
                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8));
                BufferedReader errorReader = new BufferedReader(new InputStreamReader(process.getErrorStream(), StandardCharsets.UTF_8));

                String line;
                String lastLine = null;
                String line2;
                String lastLine2 = null;
                while ((line = reader.readLine()) != null) {
                    lastLine = line; // 更新lastLine变量
                    System.out.println("这是为啥啊:"+lastLine);
                }

               process.waitFor();
                while ((line2 = errorReader.readLine()) != null) {
                    lastLine2 = line2; // 更新lastLine变量
                    System.out.println("这是为啥啊:"+lastLine2);
                }

                reader.close();
                // 等待脚本执行完毕
                String pythonOutput = lastLine;
                System.out.println("用户:"+pythonOutput);

                if (Integer.parseInt(pythonOutput)==0){
                    return Result.Error("粉丝数不达标");
                }else if(Integer.parseInt(pythonOutput)==1){
                    return Result.success("添加or更新成功!");
                }else{
                    return Result.Error("添加or更新失败!");
                }
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
                return Result.Error("添加失败");
            }


        }




    }

}
