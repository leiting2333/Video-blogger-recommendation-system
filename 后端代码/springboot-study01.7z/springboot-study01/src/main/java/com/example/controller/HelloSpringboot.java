package com.example.controller;
import com.example.common.Result;
import com.example.pojo.Params;
import com.example.pojo.UpInfoSecond;
import com.example.pojo.UpVideo;
import com.example.pojo.UserInfo;
import com.example.service.inter.UpInfoService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@CrossOrigin
@RestController
public class HelloSpringboot {
    @Resource(name="upInfoServiceImp")
    UpInfoService upInfoService;

    @RequestMapping("/upInfo")
    public Result getUpInfo(Params params){
        System.out.println("进入了");
        return Result.success(upInfoService.queryUpInfoList(params)) ;
    }
    @RequestMapping("/upInfo/updateDistribution")
    public Result updateDistribution(){
        System.out.println("分类更新");
        return Result.success(upInfoService.queryUpInfoListTwo()) ;
    }

    @RequestMapping("/upInfo/getDistribution")//获取分区表中的数据
    public Result getDistribution(){
        return Result.success(upInfoService.queryDistribution()) ;
    }
    @RequestMapping("/upInfo/searchByUid")
    public Result searchUpInfoById(Params params){
        System.out.println(params);
        if (params.getInput1()==null){
            return Result.Error("没查询到相应博主");
        }else {
            return Result.success(upInfoService.queryUpInfoByUid(params));
        }

    }
    @RequestMapping("/upInfo/searchByName")
    public Result searchUpInfoByName(Params params){
        System.out.println(params);
        if (params.getInput1()==null || params.getInput1().equals("")){
            return Result.Error("请输入名称");
        }else {
            //System.out.println(upInfoService.queryUpInfoByName(params));
            return Result.success(upInfoService.queryUpInfoByName(params));
        }

    }
    @RequestMapping("/upInfo/searchByCategory")
    public Result searchUpInfoByCategory(Params params){
        System.out.println(params);
        if (params.getInput1()==null || params.getInput1().equals("")){
            return Result.Error("请输入分区");
        }else {
            //System.out.println(upInfoService.queryUpInfoByName(params));
            return Result.success(upInfoService.searchByCategory(params));
        }

    }

    @RequestMapping("/userInfo/userFlash")
    public Result userFlash(){
        List<UpInfoSecond> upInfoSeconds = upInfoService.queryUpByPre();
        if (!upInfoSeconds.isEmpty() && upInfoSeconds.size()<4){
            int i = upInfoService.queryUpByUidTwo();
            UpInfoSecond upInfoSecond = upInfoService.queryUpInfoSecondByUid(i);
            upInfoSeconds.add(upInfoSecond);
            return Result.success(upInfoSeconds);
        } else if (upInfoSeconds.size()==4) {
            return Result.success(upInfoSeconds);
        }

        /**
         * 判断该用户的点赞列表是长度是否小于5,Likelist中的list长度
         * 如果小于5就调用模型预测出用户的偏好权重
         * 把这个权重值和通过喜欢列表得到的权重值加起来写到数据库中
         */
        return Result.Error("没有对应博主");

    }

    @GetMapping("/upInfo/delUpInfo/{uid}")
    public Result delUpInfo(@PathVariable long uid){
            //System.out.println(upInfoService.queryUpInfoByName(params));
        int i = upInfoService.deleteUpInfo(uid);
        if (i==1){
            return Result.success(upInfoService.deleteUpInfo(uid));
        }else {
            return Result.Error("删除失败");
        }


    }

}
