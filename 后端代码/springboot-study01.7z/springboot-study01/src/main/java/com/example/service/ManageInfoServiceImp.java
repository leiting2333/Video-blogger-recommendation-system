package com.example.service;

import com.example.dao.ManageInfoMapper;
import com.example.dao.UserInfoMapper;
import com.example.exception.CustomException;
import com.example.pojo.Login;
import com.example.pojo.ManageInfo;
import com.example.pojo.Params;
import com.example.pojo.UserInfo;
import com.example.service.inter.ManageInfoService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class ManageInfoServiceImp implements ManageInfoService {
    @Resource
    private ManageInfoMapper manageInfoMapper;

    public void setManageInfoMapper(ManageInfoMapper manageInfoMapper) {
        this.manageInfoMapper = manageInfoMapper;
    }

    @Override
    public PageInfo<ManageInfo> queryManageInfoList(Params params) {
        PageHelper.startPage(params.getCurrentPage(), params.getPageSize());
        List<ManageInfo> manageInfos = manageInfoMapper.queryManageInfoList();
        return PageInfo.of(manageInfos);
    }

    @Override
    public PageInfo<ManageInfo> queryManageInfoByNumber(Params params) {
        PageHelper.startPage(params.getCurrentPage(), params.getPageSize());
        List<ManageInfo> manageInfos = manageInfoMapper.queryManageInfoByNumber(Long.parseLong(params.getInput1()));
        return PageInfo.of(manageInfos);
    }

    @Override
    public List<ManageInfo> queryManageInfoByNumberLimit(Login login) {
        return manageInfoMapper.queryManageInfoByNumberLimit(Long.parseLong(login.getEmail()));
    }

    @Override
    public PageInfo<ManageInfo> queryManageInfoByName(Params params) {
        List<ManageInfo> manageInfos = manageInfoMapper.queryManageInfoByName(params.getInput1());
        return PageInfo.of(manageInfos);
    }

    public static boolean isChinesePhoneNumber(String phoneNumber) {
        // 中国大陆手机号码正则表达式
        // 1[34578]\d{9} 表示以1开头，第二位为3、4、5、7、8中的一个，后面跟9个任意数字
        String regex = "^1[34578]\\d{9}$";
        return phoneNumber != null && phoneNumber.matches(regex);
    }

    @Override
    public void addManageInfo(ManageInfo manageInfo) {
        if ( !isChinesePhoneNumber(String.valueOf(manageInfo.getNumber())) || manageInfo.getAge() < 1 || manageInfo.getName() == null || manageInfo.getName() == "" || manageInfo.getSex() == null || manageInfo.getSex() == "") {
            throw new CustomException("信息不能为空或不符!");
        }
        if (!manageInfoMapper.queryManageInfoByNumberLimit(manageInfo.getNumber()).isEmpty()) {
            throw new CustomException("用户已存在!");
        } else {
            if (manageInfo.getPassword() == null) {
                manageInfo.setPassword("123456");
            }
            manageInfoMapper.addManageInfo(manageInfo);
        }


    }

    @Override
    public void updateManageInfo(ManageInfo manageInfo) {
        if (manageInfo.getNumber() <= 1 || manageInfo.getAge() < 1 || manageInfo.getName() == null || manageInfo.getName() == "" || manageInfo.getSex() == null || manageInfo.getSex() == "") {
            throw new CustomException("信息不能为空!");
        }
        if (!isChinesePhoneNumber(String.valueOf(manageInfo.getNumber()))) {
            throw new CustomException("手机号有误!");
        } else {
            manageInfoMapper.updateManageInfo(manageInfo);
        }

    }

    @Override
    public int deleteManageInfo(ManageInfo manageInfo) {
        return manageInfoMapper.deleteManageInfo(manageInfo);
    }
}
