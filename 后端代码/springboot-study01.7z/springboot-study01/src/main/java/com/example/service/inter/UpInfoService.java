package com.example.service.inter;

import com.example.pojo.*;
import com.github.pagehelper.PageInfo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UpInfoService {

    PageInfo<UpInfo> queryUpInfoList(Params params);
    int queryUpInfoListTwo( );
    PageInfo<UpInfo> queryUpInfoByUid( Params params);
    PageInfo<UpInfo> queryUpInfoByName( Params params);
    PageInfo<UpInfo> searchByCategory( Params params);
    int addUpInfo( int uid);

    int deleteUpInfo(long uid);
    UpInfoSecond queryUpInfoSecondByUid(@Param("uid") int uid);
    List<UpVideo> queryUpVideoByUid(@Param("uid") int uid);
    int [] queryUpByUid();
    int queryUpByUidTwo();
    List<UpInfoSecond> queryUpByPre();
    void updateDistribution(Distribution distribution);
    Distribution  queryDistribution();

}
