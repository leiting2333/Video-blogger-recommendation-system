package com.example.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UpVideo {
    private Integer uid;
    private  String video_title;
    private Integer video_viewing_frequency;
    private  String video_danmaku;
    private Integer video_time;
    private String  video_picture;
    private int video_like;
    private int video_coin;
    private Integer video_favorite;
    private  String video_short_link_v2;

}
