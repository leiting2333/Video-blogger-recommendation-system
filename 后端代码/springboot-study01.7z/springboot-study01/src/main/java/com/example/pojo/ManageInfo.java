package com.example.pojo;

import lombok.Data;

@Data
public class ManageInfo {
    private Integer id;
    private String name;
    private long number;
    private int age;
    private String password;
    private String  sex;

    private String token;
}
