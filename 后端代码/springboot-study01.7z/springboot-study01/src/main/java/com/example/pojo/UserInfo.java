package com.example.pojo;


import lombok.Data;

import java.beans.Transient;

@Data
public class UserInfo {
    private Long id;
    private String name;
    private String password;
    private String  sex;
    private String like;
    private int age;
    private String email;
    private  int career;
    private String like_list;
    private String[] likes;
    private String token;

}
