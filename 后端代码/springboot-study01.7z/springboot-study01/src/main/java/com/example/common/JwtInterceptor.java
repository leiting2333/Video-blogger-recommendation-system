package com.example.common;
import cn.hutool.core.util.StrUtil;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.example.controller.LoginAndRegisterController;
import com.example.exception.CustomException;
import com.example.pojo.Login;
import com.example.pojo.ManageInfo;
import com.example.pojo.UserInfo;
import com.example.service.inter.ManageInfoService;
import com.example.service.inter.UserInfoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * jwt拦截器
 */
@Component
public class JwtInterceptor implements HandlerInterceptor {
    public   static  String  email = null;
    private static final Logger log = LoggerFactory.getLogger(JwtInterceptor.class);

    @Resource
    private UserInfoService userInfoService;
    @Resource
    private ManageInfoService manageInfoService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        // 1. 从http请求的header中获取token
        String token = request.getHeader("token");
        if (StrUtil.isBlank(token)) {
            // 如果没拿到，我再去参数里面拿一波试试  /api/admin?token=xxxxx
            token = request.getParameter("token");
        }
        // 2. 开始执行认证
        if (StrUtil.isBlank(token)) {
            System.out.println("找到的token为:"+token);
            throw new CustomException("无token，请重新登录");
        }
        // 获取 token 中的email或者number
        String msg;
        UserInfo userInfo = null;
        ManageInfo manageInfo=null;
        try {
            msg = JWT.decode(token).getAudience().get(0);
            Login login = new Login();
            //如果是手机号则去管理员表查询
            if(LoginAndRegisterController.isChinesePhoneNumber(msg)){
                // 根据token中的userid查询数据库
                login.setEmail(msg);
                List<ManageInfo> manageInfos = manageInfoService.queryManageInfoByNumberLimit(login);
                manageInfo=manageInfos.get(0);
            }else {
                login.setEmail(msg);
                List<UserInfo> userInfos = userInfoService.queryUpInfoByEmail(login);
                userInfo=userInfos.get(0);

            }

        } catch (Exception e) {
            String errMsg = "token验证失败，请重新登录";
            log.error(errMsg + ", token=" + token, e);
            throw new CustomException(errMsg);
        }
        if (userInfo == null && manageInfo==null) {
            throw new CustomException("用户不存在，请重新登录");
        }
        try {
            // 用户密码加签验证 token
            if (userInfo!=null){
                JWTVerifier jwtVerifier = JWT.require(Algorithm.HMAC256(userInfo.getPassword())).build();
                jwtVerifier.verify(token); // 验证token
                JwtInterceptor.email=userInfo.getEmail();
            }
            if (manageInfo!=null){
                JWTVerifier jwtVerifier = JWT.require(Algorithm.HMAC256(manageInfo.getPassword())).build();
                jwtVerifier.verify(token); // 验证token
            }

        } catch (JWTVerificationException e) {
            throw new CustomException("token验证失败，请重新登录");
        }
        return true;
    }
}