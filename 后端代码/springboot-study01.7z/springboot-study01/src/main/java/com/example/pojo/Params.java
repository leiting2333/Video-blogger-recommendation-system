package com.example.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Params {
    private String input1;
    private int pageSize;
    private long number;
    private int currentPage;
    private String email;
    private String password;
    private String uid;
}
