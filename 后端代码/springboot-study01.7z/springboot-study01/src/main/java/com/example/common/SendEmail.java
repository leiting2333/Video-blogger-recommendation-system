package com.example.common;

import ch.qos.logback.classic.spi.EventArgUtil;
import org.springframework.mail.SimpleMailMessage;

public class SendEmail {
    public void commonEmail(String toEmail) {
        //创建简单邮件消息
        SimpleMailMessage message = new SimpleMailMessage();
        //谁发的
        message.setFrom("2053713054@qq.com");
        //谁要接收
        message.setTo(toEmail);
        //邮件标题
        message.setSubject("欢迎注册UpUp视频推荐平台");
        //邮件内容


    }
}