package com.example.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.ibatis.annotations.Select;
import org.springframework.context.annotation.Bean;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UpInfoSecond {
    private long uid ;
    private  String name;
    private  String sex;
    private  String face;
    private  String  sign;
    private  int score;
    private  int level;
    private  String  title;
    private  String vip_type;
    private String live_room;
    private String birthday;
    private  String school;
    private  String homepage;
    private  int following;
    private int follower;
    private  String tid;
    private String location;
    private   List<UpVideo> upVideos;
    private   List<Videos> videos;
    private String fansChart;
}
