package com.example.service.inter;

import com.example.pojo.Login;
import com.example.pojo.ManageInfo;
import com.example.pojo.Params;
import com.example.pojo.UpInfo;
import com.github.pagehelper.PageInfo;

import java.util.List;

public interface ManageInfoService {
    PageInfo<ManageInfo> queryManageInfoList(Params params);
    PageInfo<ManageInfo> queryManageInfoByNumber( Params params);
    List<ManageInfo> queryManageInfoByNumberLimit(Login login);
    PageInfo<ManageInfo> queryManageInfoByName( Params params);
    void addManageInfo( ManageInfo manageInfo);
    void updateManageInfo(ManageInfo manageInfo);

    int deleteManageInfo(ManageInfo manageInfo);
}
