package com.example.dao;

import com.example.pojo.ManageInfo;
import com.example.pojo.UserInfo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserInfoMapper {
    List<UserInfo> queryUpInfoList();
    List<UserInfo> queryUpInfoByName(@Param("name") String name);
    List<UserInfo> queryUpInfoByEmail(@Param("email") String email);
    List<UserInfo> queryUpInfoByEmailLimit(@Param("email") String email);
    int addUserInfo(UserInfo userInfo);
    void updateUserInfo(UserInfo userInfo);
    int delUserInfo(UserInfo userInfo);
     void  updateUserInfoByEmail(UserInfo userInfo);
    void  updateUserInfoLikeList(UserInfo userInfo);

}
