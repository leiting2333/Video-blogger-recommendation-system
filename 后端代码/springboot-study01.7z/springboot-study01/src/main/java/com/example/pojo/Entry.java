package com.example.pojo;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

@Getter
public class Entry {
    @JsonProperty("name")
    private String name;

    @JsonProperty("count")
    private int count;

    // 构造器、getter和setter方法

    @JsonCreator
    public Entry(@JsonProperty("name") String name, @JsonProperty("count") int count) {
        this.name = name;
        this.count = count;
    }

    // toString方法（可选）
    @Override
    public String toString() {
        return "Entry{" +
                "name='" + name + '\'' +
                ", count=" + count +
                '}';
    }
}