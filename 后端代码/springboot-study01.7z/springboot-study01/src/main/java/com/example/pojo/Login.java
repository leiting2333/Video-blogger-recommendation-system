package com.example.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Login {
    private String email;
    private String password;
    private String name;
    private String password2;

    public  boolean judgeAttr(){
        if (this.getEmail()==null || this.getPassword()==null ||this.getName()==null || this.getPassword2()==null){
            return false;
        }
        if (this.getEmail().replace(" ", "").isEmpty() || this.getPassword().replace(" ", "").isEmpty() || this.getPassword2().replace(" ", "").isEmpty() || this.getName().replace(" ", "").isEmpty()){
            return false;
        }
        return true;
    }
}
