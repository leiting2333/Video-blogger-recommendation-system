package com.example.service.inter;

import com.example.pojo.Login;
import com.example.pojo.Params;

import com.example.pojo.UpInfoSecond;
import com.example.pojo.UserInfo;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.github.pagehelper.PageInfo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserInfoService {
    PageInfo<UserInfo> queryUpInfoList(Params params);
    PageInfo<UserInfo> queryUpInfoByEmail(Params params);
    List<UserInfo> queryUpInfoByEmail(Login login);
    PageInfo<UserInfo> queryUpInfoByName(Params params);
    void addUserInfo( UserInfo userInfo);
    void addUserInfo( Login login);
    void updateUserInfo(UserInfo userInfo);
    void  updateUserInfoByEmail(UserInfo userInfo);
    int delUserInfoById(UserInfo userInfo);

    UserInfo queryUpInfoByEmail(String email);

    void addLikeList( String uid);

    List<UpInfoSecond> queryUpInfoSecondByUid() throws JsonProcessingException;




}
