package com.example.service;

import com.example.common.JwtInterceptor;
import com.example.common.JwtTokenUtils;
import com.example.common.LikeLinkedList;
import com.example.common.Result;
import com.example.controller.LoginAndRegisterController;
import com.example.dao.UpInfoMapper;
import com.example.dao.UserInfoMapper;
import com.example.exception.CustomException;
import com.example.pojo.*;
import com.example.service.inter.UserInfoService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.json.JSONArray;
import org.json.JSONException;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;


@Service
public class UserInfoServiceImp implements UserInfoService {
    @Resource
    private UserInfoMapper userInfoMapper;
    @Resource
    private UpInfoMapper upInfoMapper;

    public void setUserInfoMapper(UserInfoMapper userInfoMapper) {
        this.userInfoMapper = userInfoMapper;
    }

    @Override
    public PageInfo<UserInfo> queryUpInfoList(Params params) {
        PageHelper.startPage(params.getCurrentPage(), params.getPageSize());
        List<UserInfo> userInfos = userInfoMapper.queryUpInfoList();

        return PageInfo.of(userInfos);
    }

    @Override
    public PageInfo<UserInfo> queryUpInfoByEmail(Params params) {
        PageHelper.startPage(params.getCurrentPage(), params.getPageSize());
        List<UserInfo> userInfos = userInfoMapper.queryUpInfoByEmail(params.getInput1());
        return PageInfo.of(userInfos);
    }

    @Override
    public List<UserInfo> queryUpInfoByEmail(Login login) {
        String replace = login.getEmail().replace(" ", "");
        return userInfoMapper.queryUpInfoByEmailLimit(replace);
    }

    @Override
    public PageInfo<UserInfo> queryUpInfoByName(Params params) {
        PageHelper.startPage(params.getCurrentPage(), params.getPageSize());
        List<UserInfo> userInfos = userInfoMapper.queryUpInfoByName(params.getInput1());
        return PageInfo.of(userInfos);
    }

    @Override
    public void addUserInfo(UserInfo userInfo) {
        if (userInfo.getEmail() == null || userInfo.getEmail() == "" || userInfo.getAge() < 1 || userInfo.getName() == null || userInfo.getName() == "" || userInfo.getSex() == null || userInfo.getSex() == "") {
            throw new CustomException("信息不能为空!");
        }
        if (!userInfoMapper.queryUpInfoByEmailLimit(userInfo.getEmail().replace(" ", "")).isEmpty()) {
            throw new CustomException("用户已存在!!");
        } else {
            if (userInfo.getPassword() == null) {
                userInfo.setPassword("123456");
            }
            userInfoMapper.addUserInfo(userInfo);
        }


    }

    @Override
    public void addUserInfo(Login login) {
        UserInfo userInfo = new UserInfo();
        userInfo.setEmail(login.getEmail());
        userInfo.setPassword(login.getPassword());
        userInfo.setName(login.getName());
        userInfoMapper.addUserInfo(userInfo);
    }

    @Override
    public void updateUserInfo(UserInfo userInfo) {
        if (userInfo.getEmail() == null || userInfo.getEmail() == "" || userInfo.getAge() < 1 || userInfo.getName() == null || userInfo.getName() == "" || userInfo.getSex() == null || userInfo.getSex() == "") {
            throw new CustomException("信息不能为空!");
        }
        if (!userInfoMapper.queryUpInfoByEmailLimit(userInfo.getEmail().replace(" ", "")).isEmpty()) {
            throw new CustomException("用户已存在!!");
        } else {
            userInfoMapper.updateUserInfo(userInfo);
        }
        if (userInfo.getPassword() == null) {
            userInfo.setPassword("123456");
        }

    }
    //该方法用于将字符串的double[][]数组转成真的数组
    public static double[][] convertJsonToDoubleArray(String jsonString) {
        try {
            JSONArray jsonArray = new JSONArray(jsonString);
            double[][] result = new double[jsonArray.length()][];

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONArray innerArray = jsonArray.getJSONArray(i);
                result[i] = new double[innerArray.length()];

                for (int j = 0; j < innerArray.length(); j++) {
                    result[i][j] = innerArray.getDouble(j);
                }
            }

            return result;

        } catch (JSONException e) {
            e.printStackTrace();
            return null; // 或者抛出一个自定义异常
        }
    }

    public static int findAgeInterval(int age) {
        // 假设年龄区间是从0岁到120岁，每个区间10岁
        // 因为区间是从0开始编号的，所以我们需要将年龄除以10并向下取整来得到区间编号
        // 注意：Java的除法会自动向下取整，因此不需要额外的Math.floor操作
        if (age < 0 || age > 120) {
            throw new IllegalArgumentException("年龄必须在0到120岁之间（包含0和120）");
        }
        return age / 10;
    }
    @Override
    public void updateUserInfoByEmail(UserInfo userInfo) {
        //获得用户的email,设置给传递进来的userinfo对象
        userInfo.setEmail(JwtInterceptor.email);

        //从数据库中找到该用户的信息
        List<UserInfo> userInfos = userInfoMapper.queryUpInfoByEmailLimit(userInfo.getEmail());
        UserInfo userInfo1 = userInfos.get(0);//从数据库中抓取该用户的信息
        if (userInfo1==null){
            throw new CustomException("提交失败!!");
        }
        //将likes中的偏好写入like
        System.out.println("第一次填表"+userInfo.getLike());//记得删除
        if (userInfo1.getLike()==null || userInfo1.getLike().isEmpty()){
            double[] i={0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1};//如果用户的like为空
            if (userInfo.getLikes()!=null && userInfo.getLikes().length>=1){//这个userinfo是前端传进来的,userInfo1是从数据库中查出来的

                for (String like : userInfo.getLikes()) {//这个userinfo是前端传进来的,userInfo1是从数据库中查出来的
                    i[Integer.parseInt(like)]+=0.9;
                }
                //这里调用预测模型的方法来把权重加进去.
                try {
                    //将博主的年龄,性别,职业特征加到数组中
                    int[] user_characteristics=new int[3];
                    user_characteristics[0]=findAgeInterval(userInfo.getAge());
                    user_characteristics[2]=userInfo.getCareer();
                    if (userInfo.getSex()=="男"){
                        user_characteristics[1]=0;
                    }else {
                        user_characteristics[1]=1;
                    }

                    // 构建Python脚本命令
                    String command = "python  D:\\project\\PyProject\\hello\\project01\\test\\test6.py " + Arrays.toString(user_characteristics);
                    // 执行Python脚本
                    Process process = Runtime.getRuntime().exec(command);

                    // 读取Python脚本输出
                    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8));
                    String line;
                    String lastLine = null;
                    while ((line = reader.readLine()) != null) {
                        lastLine = line; // 更新lastLine变量
                    }
                    String pythonOutput = lastLine;
                    reader.close();
                    // 等待脚本执行完毕
                    process.waitFor();
                    System.out.println("用户预测出的权重值为:"+pythonOutput);
                    double[][] doubleArray = convertJsonToDoubleArray(pythonOutput);
                    // 遍历updates数组并更新i数组
                    for (double[] update : doubleArray) {
                        int index = (int) Math.min(update[0], i.length - 1); // 确保索引在i数组范围内
                        i[index] += update[1]*10; // 将第二个值加到i数组的对应位置上
                    }
                } catch (IOException | InterruptedException e) {
                    e.printStackTrace();

                }

            }else {
                try {
                    //将博主的年龄,性别,职业特征加到数组中
                    System.out.println("不应该起作用的");
                    int[] user_characteristics=new int[3];
                    user_characteristics[0]=findAgeInterval(userInfo.getAge());
                    user_characteristics[2]=userInfo.getCareer();
                    if (Objects.equals(userInfo.getSex(), "女")){//默认是零所以不用判断男
                        user_characteristics[1]=1;
                    }else {
                        user_characteristics[1]=0;
                    }
                    System.out.println(Arrays.toString(user_characteristics));//记得删
                    String s=Arrays.toString(user_characteristics);
                    // 构建Python脚本命令
                    String command = "python  D:\\project\\PyProject\\hello\\project01\\test\\test6.py " + s;
                    // 执行Python脚本
                    Process process = Runtime.getRuntime().exec(command);

                    // 读取Python脚本输出
                    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8));
                    String line;
                    String lastLine = null;
                    while ((line = reader.readLine()) != null) {
                        lastLine = line; // 更新lastLine变量
                    }
                    String pythonOutput = lastLine;
                    reader.close();
                    // 等待脚本执行完毕
                    process.waitFor();
                    System.out.println("用户预测出的权重值为:"+pythonOutput);
                    double[][] doubleArray = convertJsonToDoubleArray(pythonOutput);
                    // 遍历updates数组并更新i数组
                    for (double[] update : doubleArray) {
                        int index = (int) Math.min(update[0], i.length - 1); // 确保索引在i数组范围内
                        i[index] += update[1]*10; // 将第二个值加到i数组的对应位置上
                    }
                } catch (IOException | InterruptedException e) {
                    e.printStackTrace();

                }
            }
            //调用脚本使得预测的权重值加到
            userInfo1.setLike(Arrays.toString(i));
        }

        userInfo1.setAge(userInfo.getAge());
        userInfo1.setSex(userInfo.getSex());
        userInfo1.setCareer(userInfo.getCareer());

        userInfoMapper.updateUserInfoByEmail(userInfo1);

    }

    @Override
    public int delUserInfoById(UserInfo userInfo) {
        return userInfoMapper.delUserInfo(userInfo);
    }

    @Override
    public UserInfo queryUpInfoByEmail(String email) {
        List<UserInfo> userInfos = userInfoMapper.queryUpInfoByEmailLimit(email);
        return userInfos.get(0);
    }

    @Override
    public void addLikeList(String uid) {
        //获得单利模式的实例化对象,用这个对象调用里面的方法
        LikeLinkedList instance = LikeLinkedList.getInstance();
        //获得发送请求的用户的信息
        List<UserInfo> userInfos = userInfoMapper.queryUpInfoByEmailLimit(JwtInterceptor.email);
        //接受计算更新以后的喜欢列表的对象,通过下面的更新语句来将对象中的值给跟新了
        UserInfo userInfo = instance.addLikeList(uid, userInfos.get(0));//即便是第一次请求,也是有博主的uid在列表里

        try {
            String s = calculateLikePre(userInfo);//计算喜欢列表的权重值
            System.out.println("权重添加之后"+s);//输出加权之后代理喜欢列表,代指权重数组,该处出现问题,第一次为null
            if (s!=null && !s.isEmpty()){
                userInfo.setLike(s);
            }
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }


        userInfoMapper.updateUserInfoLikeList(userInfo);

    }

    /**
     *
     * @param userInfo
     * @return
     * @throws JsonProcessingException
     * 该方法用于计算博主列表中uid所处分区的权重,然后将权重加到like列表里面.
     */
    public static UserInfo userInfoPub = null;
    public  String calculateLikePre(UserInfo userInfo) throws JsonProcessingException {
        userInfoPub=userInfo;
        System.out.println(userInfo);//记得删
        List<UpInfoSecond> upInfoSeconds = queryUpInfoSecondByUid2();//方法在下面,这一步是获得用户的点赞的列表的博主信息,当前这个有误
        String writeList =null;
                //把喜欢的权重读取出来
        String like = userInfo.getLike();
        double[] likes=null;
        if (like!=null && !like.isEmpty()){
            //把喜欢的权重转成数组
            likes=returnIntList(like);
        }

        System.out.println("权重添加之前"+Arrays.toString(likes));//输出权重列表
        if (likes!=null && likes.length>0 && !upInfoSeconds.isEmpty()){
            if (upInfoSeconds.size()>=20){//如果我们的喜欢列表大于等于20,重新算喜欢权重值
                double[] li=new double[20];
                for (UpInfoSecond upInfoSecond : upInfoSeconds) {
                    String tid = upInfoSecond.getTid();
                    if (tid!=null && !tid.isEmpty()){
                        ObjectMapper mapper = new ObjectMapper();
                        List<Entry> entries = mapper.readValue(tid, mapper.getTypeFactory().constructParametricType(List.class, Entry.class));//这两句代码是将json格式的字符加载到对象列表中
                        li = calculateLike(li, entries);//这一步将喜欢列表中的权重值加到权重列表

                    }

                }
                writeList= Arrays.toString(li);
            }else {//当upInfoSeconds的长度小于20的时候,我们只需要将最后一个对象的权重加进去即可
                UpInfoSecond upInfoSecond = upInfoSeconds.get(0);
                String tid = upInfoSecond.getTid();
                System.out.println(tid);//记得删
                if (tid!=null && !tid.isEmpty()){
                    ObjectMapper mapper = new ObjectMapper();
                    List<Entry> entries = mapper.readValue(tid, mapper.getTypeFactory().constructParametricType(List.class, Entry.class));//这两句代码是将json格式的字符加载到对象列表中
                    writeList= Arrays.toString(calculateLike(likes, entries));  //这一步将喜欢列表中的权重值加到权重列表
                }
            }

        }else{
            for (UpInfoSecond upInfoSecond : upInfoSeconds) {
                String tid = upInfoSecond.getTid();
                if (tid!=null && !tid.isEmpty()){
                    ObjectMapper mapper = new ObjectMapper();
                    List<Entry> entries = mapper.readValue(tid, mapper.getTypeFactory().constructParametricType(List.class, Entry.class));
                    double[] ints = new double[20];
                    writeList = Arrays.toString(calculateLike(ints, entries));

                }

            }
        }

        return writeList;
    }
    public static String[] convertToArray(String input) {
        // 去掉开头和结尾的括号
        input = input.substring(1, input.length() - 1);
        // 使用逗号和空格作为分隔符分割字符串
        return input.split(",\\s*"); // "\\s*" 用于匹配零个或多个空白字符
    }

    public static double[] calculateLike(double[] input, List<Entry>  list) {
       String [] zone={"动画", "国创", "音乐", "舞蹈","游戏","知识","科技","运动","汽车","生活","美食","电影","鬼畜","时尚","资讯","娱乐","影视","纪录片","动物圈","电视剧"};

       for (int i = 0; i < list.size()-1; i++) {
           for (int j = 0; j < zone.length; j++) {
               if (Objects.equals(list.get(i).getName(), zone[j])){
                   double i1 = input[j] + ((double) list.get(i).getCount() / list.get(list.size() - 1).getCount());
                   input[j]= i1;
               }
           }

        }

       return input;
    }

    public static double[] returnIntList(String input){
        input = input.substring(1, input.length() - 1);

        // 使用逗号分割字符串为数组
        String[] numbersStr = input.split(",");

        // 将字符串数组转换为int数组
        double[] numbers = new double[numbersStr.length];
        for (int i = 0; i < numbersStr.length; i++) {
            // 去掉可能的空格并转换为整数
            numbers[i] = Double.parseDouble(numbersStr[i].trim());
        }
        return numbers;
    }
    @Override
    public List<UpInfoSecond> queryUpInfoSecondByUid() {//将喜欢列表中的对象都添加到列表中并返回
        //获得该用户的喜好列表
        LikeLinkedList instance = LikeLinkedList.getInstance();
        List<UserInfo> userInfos = userInfoMapper.queryUpInfoByEmailLimit(JwtInterceptor.email);
        UserInfo userInfo = userInfos.get(0);
        //创建一个链表,用来存储喜欢列表中的对象
        List<UpInfoSecond> upInfoSeconds = new ArrayList<>();
        String likeList = userInfo.getLike_list();//获取用户的点赞的喜欢列表
        if (likeList==null || Objects.equals(likeList, "")){//以防万一第一次点击时,数据库中没有,所以第一次的点赞权重加不上.
            System.out.println("限制第一次的");//记得删
            likeList=userInfoPub.getLike_list();
        }
        if (!Objects.equals(likeList, "") && likeList!=null ){
            //这个是喜欢列表的内容
            String[] arr = convertToArray(likeList);
            for (String s : arr) {
                UpInfoSecond upInfoSecond = upInfoMapper.queryUpInfoSecondByUid(Integer.parseInt(s));
                upInfoSeconds.add(upInfoSecond);
            }

        }

        return upInfoSeconds ;
    }


    public List<UpInfoSecond> queryUpInfoSecondByUid2() {//专门在点赞的使用使用的方法
        //获得该用户的喜好列表
        LikeLinkedList instance = LikeLinkedList.getInstance();
        List<UserInfo> userInfos = userInfoMapper.queryUpInfoByEmailLimit(JwtInterceptor.email);
        UserInfo userInfo = userInfos.get(0);
        //创建一个链表,用来存储喜欢列表中的对象
        List<UpInfoSecond> upInfoSeconds = new ArrayList<>();
        String likeList = userInfo.getLike_list();//获取用户的点赞的喜欢列表
        if (likeList==null || Objects.equals(likeList, "")){//以防万一第一次点击时,数据库中没有,所以第一次的点赞权重加不上.
            System.out.println("限制第一次的");//记得删
            likeList=userInfoPub.getLike_list();
        }
        if (!Objects.equals(likeList, "") && likeList!=null ){
            //这个是喜欢列表的内容
            String[] arr = convertToArray(userInfoPub.getLike_list());
            for (String s : arr) {
                UpInfoSecond upInfoSecond = upInfoMapper.queryUpInfoSecondByUid(Integer.parseInt(s));
                upInfoSeconds.add(upInfoSecond);
            }



        }

        return upInfoSeconds ;
    }

}
