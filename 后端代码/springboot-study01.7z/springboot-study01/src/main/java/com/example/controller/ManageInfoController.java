package com.example.controller;

import com.example.common.Result;
import com.example.pojo.ManageInfo;
import com.example.pojo.Params;
import com.example.service.inter.ManageInfoService;
import com.example.service.inter.UserInfoService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@CrossOrigin
@RestController
public class ManageInfoController {
    @Resource(name = "manageInfoServiceImp")
    ManageInfoService manageInfoService;

    @RequestMapping("/manageInfo")
    public Result getUserInfo(Params params) {
        return Result.success(manageInfoService.queryManageInfoList(params));
    }

    @RequestMapping("/manageInfo/searchByName")
    public Result getUserInfoByName(Params params) {
        System.out.println("进入了管理员名称查询");
        if (params.getInput1() == null) {
            return Result.Error("没查询到管理");
        }
        return Result.success(manageInfoService.queryManageInfoByName(params));
    }

    @RequestMapping("/manageInfo/searchByNumber")
    public Result getUserInfoByEmail(Params params) {
        System.out.println("进入了用管理手机号查询");
        if (params.getInput1() == null) {
            return Result.Error("不能为空!");
        }
        System.out.println(params);
        return Result.success(manageInfoService.queryManageInfoByNumber(params));
    }

    @RequestMapping("/manageInfo/addManageInfo")
    public Result addManageInfo(@RequestBody ManageInfo manageInfo) {
        System.out.println(manageInfo);
        if ( manageInfo.getId() == null) {
           manageInfoService.addManageInfo(manageInfo);
            return Result.success();
        } else {
            manageInfoService.updateManageInfo(manageInfo);
            return Result.success();
        }
    }
    @RequestMapping("/manageInfo/delManageInfo")
    public Result delManageInfo(@RequestBody ManageInfo manageInfo) {
        if ( manageInfo.getId() != null) {
            return Result.success(manageInfoService.deleteManageInfo(manageInfo));
        } else {
            return Result.Error("不存在");
        }
    }
}
