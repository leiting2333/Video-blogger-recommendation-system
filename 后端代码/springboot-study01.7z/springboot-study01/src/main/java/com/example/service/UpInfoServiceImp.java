package com.example.service;

import com.example.common.JwtInterceptor;
import com.example.common.Result;
import com.example.dao.UpInfoMapper;
import com.example.dao.UserInfoMapper;
import com.example.pojo.*;

import com.example.service.inter.UpInfoService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

@Service
public class UpInfoServiceImp implements UpInfoService {

    @Resource
    private UpInfoMapper upInfoMapper;
    @Resource
    private UserInfoMapper userInfoMapper;
    public void setUpInfoMapper(UpInfoMapper upInfoMapper) {
        this.upInfoMapper = upInfoMapper;
    }

    @Override
    public PageInfo<UpInfo> queryUpInfoList(Params params) {
        PageHelper.startPage(params.getCurrentPage(),params.getPageSize());
        List<UpInfo> upInfos = upInfoMapper.queryUpInfoList();
       return PageInfo.of(upInfos);
    }

    @Override
    public int queryUpInfoListTwo() {//这个方法就是用来跟新数据库分类统计的
        List<UpInfo> upInfos = upInfoMapper.queryUpInfoList();
        // 初始化性别和分区统计Map
        Map<String, Integer> sexCount = new HashMap<>();
        Map<String, Integer> tidCount = new HashMap<>();
        for (UpInfo upInfo : upInfos) {
            // 统计性别
            String sex = upInfo.getSex();
            sexCount.put(sex, sexCount.getOrDefault(sex, 0) + 1);
            // 解析tid并统计分区数量
            try {
                JSONArray tidArray = new JSONArray(upInfo.getTid());
//                System.out.println(tidArray);
                    JSONObject tidObj = tidArray.getJSONObject(0);
                    String name = tidObj.getString("name");
                    tidCount.put(name, tidCount.getOrDefault(name, 0) + 1);

            } catch (Exception e) {
                // 处理解析异常，比如tid不是有效的JSON字符串
                System.err.println("Error parsing tid for user: " + upInfo.getName());
            }

        }
        // 创建一个新的JSONObject
        JSONObject jsonObject = new JSONObject();
        // 遍历Map并添加键值对到JSONObject
        for (Map.Entry<String, Integer> entry : tidCount.entrySet()) {
            jsonObject.put(entry.getKey(), entry.getValue());
        }
        // 将JSONObject转换为JSON格式的字符串
        String jsonString = jsonObject.toString();
        System.out.println(jsonString);

        // 创建一个新的JSONObject
        JSONObject jsonObject2 = new JSONObject();
        // 遍历Map并添加键值对到JSONObject
        for (Map.Entry<String, Integer> entry : sexCount.entrySet()) {
            jsonObject2.put(entry.getKey(), entry.getValue());
        }
        // 将JSONObject转换为JSON格式的字符串
        String jsonString2 = jsonObject2.toString();
        // 输出JSON字符串
        System.out.println(jsonString2);
        Distribution distribution = new Distribution();

        distribution.setSex_count(jsonString2);
        distribution.setCategory_count(jsonString);
        updateDistribution(distribution);
        return 1;
    }
    @Override
    public void updateDistribution(Distribution distribution) {
        upInfoMapper.updateDistribution(distribution);
    }
    @Override
    public Distribution queryDistribution() {//返回数据库的内容
        Distribution distribution = upInfoMapper.queryDistribution();
        return distribution;
    }


    @Override
    public  PageInfo<UpInfo> queryUpInfoByUid( Params params) {
        PageHelper.startPage(params.getCurrentPage(),params.getPageSize());
        List<UpInfo> upInfos = upInfoMapper.queryUpInfoByUid(Long.parseLong(params.getInput1()));
        return PageInfo.of(upInfos);
    }

    @Override
    public PageInfo<UpInfo> queryUpInfoByName( Params params) {
        PageHelper.startPage(params.getCurrentPage(),params.getPageSize());
        List<UpInfo> upInfos = upInfoMapper.queryUpInfoByName(params.getInput1());
        return PageInfo.of(upInfos);
    }

    @Override
    public PageInfo<UpInfo> searchByCategory(Params params) {
        PageHelper.startPage(params.getCurrentPage(),params.getPageSize());
        List<UpInfo> upInfos = upInfoMapper.searchByCategory(params.getInput1());
        return PageInfo.of(upInfos);
    }

    @Override
    public int addUpInfo(int uid) {
        return upInfoMapper.addUpInfo(uid);
    }



    @Override
    public int deleteUpInfo(long uid) {
        return upInfoMapper.deleteUpInfo(uid);
    }
    @Override
    public UpInfoSecond queryUpInfoSecondByUid(int uid) {

        return  upInfoMapper.queryUpInfoSecondByUid(uid);
    }

    @Override
    public List<UpVideo> queryUpVideoByUid(int uid) {
        return  upInfoMapper.queryUpVideoByUid(uid);
    }

    @Override
    public int[] queryUpByUid() {
        return upInfoMapper.queryUpByUid();
    }

    @Override
    public int queryUpByUidTwo() {
        return upInfoMapper.queryUpByUidTwo();
    }


    //============================返回推荐的博主====================================
public static int[] findMaxIndices(double[] arr, int k) {
    if (k <= 0 || k > arr.length) {
        throw new IllegalArgumentException("k 的值无效");
    }

    int[] indices = new int[k];
    double[] copyArr = Arrays.copyOf(arr, arr.length);
    Arrays.sort(copyArr);

    for (int i = 0; i < k; i++) {
        double max = copyArr[arr.length - 1 - i];
        int index = findIndex(arr, max);
        indices[i] = index;
        // 防止重复找到同一个数
        arr[index] = Double.NEGATIVE_INFINITY;
    }

    return indices;
}
    public static int findIndex(double[] arr, double target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                return i;
            }
        }
        return -1;
    }


    @Override
    public List<UpInfoSecond> queryUpByPre() {
        //读取用户偏好数组,转成字符串数组
        //找到里面权重最高的三个分区
        //根据分区来查找到对应的博主
        //将博主信息加载到列表中并返回
        String [] zone={"动画", "国创", "音乐", "舞蹈","游戏","知识","科技","运动","汽车","生活","美食","电影","鬼畜","时尚","资讯","娱乐","影视","纪录片","动物圈","电视剧"};
        List<UpInfoSecond> upInfoSeconds = new ArrayList<>();
        List<UserInfo> userInfos = userInfoMapper.queryUpInfoByEmailLimit(JwtInterceptor.email);
        UserInfo userInfo = userInfos.get(0);
        String like = userInfo.getLike();//到这里都是在获取用户信息
        if (like!=null & !Objects.equals(like, "")){
            //把字符串数组转成double数组
            double[] strings = UserInfoServiceImp.returnIntList(like);
            //取出偏好最大的下标
            int[] maxIndices = findMaxIndices(strings, 3);
            long[] ints=new long[4];
            for (int i = 0; i < maxIndices.length; i++) {
                //查找从对应分区的随机一个博主出来
                long i1 = upInfoMapper.queryUpInfoByPre(zone[maxIndices[i]]);
                ints[i]=i1;
            }
            for (long anInt : ints) {
                if (anInt>0){
                    upInfoSeconds.add(upInfoMapper.queryUpInfoSecondByUid(anInt));
                }
            }



        }else {
            int[] ints = upInfoMapper.queryUpByUid();
            for (int anInt : ints) {
                //输出随机挑选的几个uid
                upInfoSeconds.add(upInfoMapper.queryUpInfoSecondByUid(anInt));
            }
            if (!upInfoSeconds.isEmpty()){
                return upInfoSeconds;
            }
        }



        return upInfoSeconds;
    }




}
