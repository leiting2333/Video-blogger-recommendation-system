package com.example.dao;

import com.example.pojo.ManageInfo;
import com.example.pojo.UpInfo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ManageInfoMapper {
    List<ManageInfo> queryManageInfoList();
    List<ManageInfo> queryManageInfoByNumber(@Param("number") long number);
    List<ManageInfo> queryManageInfoByNumberLimit(@Param("number") long number);
    List<ManageInfo> queryManageInfoByName(@Param("name") String name);
    int addManageInfo(ManageInfo manageInfo);

    int updateManageInfo(ManageInfo manageInfo);
    int deleteManageInfo(ManageInfo manageInfo);
}
