package com.example.pojo;

import lombok.Data;

@Data
public class Videos {
    private int comment;
    private int play;
    private String pic;
    private String description;
    private String title;
    private  String author;
    private  int mid;
    private int created;
    private String length;
    private int video_review;
    private  int aid;
    private  String bvid;
}
