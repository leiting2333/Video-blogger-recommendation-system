package com.example.dao;

import com.example.pojo.*;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
@Repository

public interface UpInfoMapper {
    List<UpInfo> queryUpInfoList();
    List<UpInfo> queryUpInfoByUid(@Param("uid") long uid);
    List<UpInfo> queryUpInfoByName(@Param("name") String name);
    List<UpInfo> searchByCategory(@Param("name") String name);//name指的是视频类别
    int addUpInfo(@Param("uid") int uid);
    int deleteUpInfo(@Param("uid") long uid);

    UpInfoSecond queryUpInfoSecondByUid(@Param("uid") long uid);
    List<UpVideo> queryUpVideoByUid(@Param("uid") int uid);
    List<Videos> queryVideoByAid(@Param("uid") int uid);
    int [] queryUpByUid();
    int queryUpByUidTwo();

    long queryUpInfoByPre(@Param("preference")String preference);
    void updateDistribution(Distribution distribution);

    Distribution  queryDistribution();
}
