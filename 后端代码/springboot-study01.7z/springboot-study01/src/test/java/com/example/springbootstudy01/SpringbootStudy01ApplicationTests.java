package com.example.springbootstudy01;

import com.example.common.LikeLinkedList;
import com.example.pojo.Distribution;
import com.example.pojo.Entry;
import com.example.pojo.UpInfoSecond;
import com.example.pojo.UpVideo;
import com.example.service.inter.UpInfoService;
import com.example.service.inter.UserInfoService;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import javax.annotation.Resource;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONException;

@SpringBootTest
class SpringbootStudy01ApplicationTests {

    @Resource(name="upInfoServiceImp")
    UpInfoService upInfoService;

    @Test
    public void contextLoads() throws SQLException {
        List<UpVideo> upInfoSeconds = upInfoService.queryUpVideoByUid(946974);
        for (UpVideo upInfoSecond : upInfoSeconds) {
            System.out.println(upInfoSecond);
        }

    }
    @Test
    public void search() throws SQLException {
        UpInfoSecond upInfoSeconds = upInfoService.queryUpInfoSecondByUid(946974);


    }

    @Test
    public void searchUid() throws SQLException {

        Distribution distribution = upInfoService.queryDistribution();
        System.out.println(distribution);

    }

  @Test
    public void anyway() throws SQLException {

      String jsonString = "[{\"name\": \"知识\", \"count\": 94}, {\"name\": \"动画\", \"count\": 39}, {\"name\": \"总count\", \"count\": 133}]";
      ObjectMapper mapper = new ObjectMapper();
      List<Entry> entries = null;
      try {
          entries = mapper.readValue(jsonString, mapper.getTypeFactory().constructParametricType(List.class, Entry.class));
      } catch (JsonProcessingException e) {
          throw new RuntimeException(e);
      }
      for (Entry entry : entries) {
          System.out.println(entry);
      }

  }
    public static double[][] convertJsonToDoubleArray(String jsonString) {
        try {
            JSONArray jsonArray = new JSONArray(jsonString);
            double[][] result = new double[jsonArray.length()][];

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONArray innerArray = jsonArray.getJSONArray(i);
                result[i] = new double[innerArray.length()];

                for (int j = 0; j < innerArray.length(); j++) {
                    result[i][j] = innerArray.getDouble(j);
                }
            }

            return result;

        } catch (JSONException e) {
            e.printStackTrace();
            return null; // 或者抛出一个自定义异常
        }
    }
    @Test
  public void  callPythonScript() throws IOException, InterruptedException {

      String pyPath = "  D:\\project\\PyProject\\hello\\project01\\test\\test7.py";
      //    两个线程解决调用python一直加载，执行一半执行不下去的情况

      try {
          int[] i={1,2,4};
          System.out.println(i);
          // 构建Python脚本命令
          String command = "python  D:\\project\\PyProject\\hello\\project01\\test\\test6.py " + Arrays.toString(i);
          // 执行Python脚本
          Process process = Runtime.getRuntime().exec(command);

          // 读取Python脚本输出
          BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8));
          String line;
          String lastLine = null;
          while ((line = reader.readLine()) != null) {
              lastLine = line; // 更新lastLine变量

          }
          String pythonOutput = lastLine;
          reader.close();

          // 等待脚本执行完毕
          process.waitFor();

          double[][] doubleArray = convertJsonToDoubleArray(pythonOutput);
          System.out.println(doubleArray);
          double[] j = new double[20]; // 初始化i数组，所有元素为1（但实际上这里初始化为0，因为Java数组默认初始化为0）
          Arrays.fill(j, 1); // 使用Arrays.fill将所有元素设置为1

          // 遍历updates数组并更新i数组
          for (double[] update : doubleArray) {
              int index = (int) Math.min(update[0], j.length - 1); // 确保索引在i数组范围内
              j[index] += update[1]*10; // 将第二个值加到i数组的对应位置上
          }
          // 打印更新后的i数组
          for (double value : j) {
              System.out.print(value + " ");
          }
          System.out.println(pythonOutput);

      } catch (IOException | InterruptedException e) {
          e.printStackTrace();

      }

  }



}
class ProcessTestRunnable implements Runnable{
    Process p;
    BufferedReader br;
    ProcessTestRunnable(Process p){
        this.p = p;
    }

    @Override
    public void run() {
        try{
            InputStreamReader isr = new InputStreamReader(p.getInputStream(),"GBK");
            br = new BufferedReader(isr);
            String line = null;
            while((line = br.readLine()) != null){
                System.out.println(line);
            }
        }catch (IOException ex){
            ex.printStackTrace();
        }

    }
}